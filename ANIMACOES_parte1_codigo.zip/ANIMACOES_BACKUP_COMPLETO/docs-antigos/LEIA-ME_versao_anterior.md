# Histórias IA — projeto de animação 2D + 3D (Cibito, Jorisvaldo e outros)

Estilo: personagens 2D com contorno preto grosso em cenários 3D, vertical 1080x1920, MP4, legendas coloridas (.ass).
Tudo é gerado por código (HTML + WebGL + Chromium + ffmpeg). Não precisa de internet.

## COMO RETOMAR EM OUTRA CONVERSA
1. Abra uma conversa nova e anexe este ZIP (projeto-historias-ia.zip).
2. Cole este pedido:
   "Descompacte o projeto-historias-ia.zip em /home/claude (as pastas titan, story e outras-animacoes devem ficar lá),
   leia o LEIA-ME.md e continue o short do Titã com o Cibito de onde parou."
3. Se enviar um MP3 de narração, peça para sincronizar legendas e boca com o áudio.

Requisitos do ambiente (precisam existir na conversa nova): Python 3 com playwright + Chromium, Pillow, numpy, ffmpeg com libx264 e libass, fonte Poppins.
Se faltar algo, o Claude precisa avisar; os arquivos .png de cenários já estão prontos e não dependem de nada para serem reaproveitados.

## PASTAS
### titan/  → short "E se você virasse um Titã" (Cibito) — 90 s — EM ANDAMENTO
| Arquivo | Para que serve |
|---|---|
| main.js | A animação: roteiro (SEG), personagens (CHD), planos (shot(...)), câmera, efeitos, sincronia |
| newmain.js, newshots.js | Partes que compõem o main.js (personagens e planos do Titã) — para consulta |
| lib.js | Desenho dos personagens 2D (função ch) + motor 3D em WebGL |
| sets.js, newsets.js | Cenários 3D (quarto 'bed', cidade de dia 'twn', cidade ao pôr do sol 'twn2') |
| plates_main.js | Renderizador das chapas 3D (fundo A e primeiro plano B) |
| plates/*.png | Chapas 3D já renderizadas (bed, twn, twn2) |
| plates.py | Gera as chapas:  python3 plates.py bed twn twn2 |
| prevs.py | Prévia de 1 quadro por plano (pv_XX.jpg) |
| rec5.py | Renderiza todos os quadros a 24 fps em frames5/ |
| caps.py | Gera as legendas coloridas /mnt/user-data/outputs/cibito-titan.ass |
| build.py | Remonta story.html e plates.html depois de editar os .js |
| story.html, plates.html | Páginas montadas (abertas pelos scripts) |
| referencia-cibito.png | Imagem do Cibito enviada por você (referência do visual) |
| previa-planos.png | Prévia dos 11 planos já montados |

### story/  → short "Sexta-feira 13" (Jorisvaldo) — PRONTO (2:35)
Mesma estrutura da pasta titan. Além disso: rec6.py (refaz só trechos de quadros), legendas-jorisvaldo.ass (legendas prontas), plates/ com 11 cenários (liv, tvw, dor, kit, str, prc, prcW, fpc, fpo, fpb, fli).

### outras-animacoes/
ultimo-homem.html, jorisvaldo.html (história do prefeito dos olhos), teste-pizzaria-3d.html (teste 3D de 6 s). Abrem direto no navegador.

## COMANDOS (dentro de titan/ ou story/)
python3 plates.py bed twn twn2      # só se mudar os cenários (sets.js)
python3 build.py                 # sempre que editar lib.js, sets.js ou main.js
python3 prevs.py                    # conferir os planos
python3 rec5.py                     # renderiza tudo (~4 a 8 min)
python3 caps.py                     # legendas coloridas
ffmpeg -framerate 24 -i frames5/%05d.jpg -vf "subtitles=/mnt/user-data/outputs/cibito-titan.ass:fontsdir=/usr/share/fonts/truetype/google-fonts" -c:v libx264 -crf 17 -pix_fmt yuv420p -movflags +faststart /mnt/user-data/outputs/cibito-titan.mp4
(Com áudio: acrescentar  -i narracao.mp3 -map 0:v -map 1:a -c:a aac  e ajustar os tempos em main.js.)

## ESTADO DO SHORT DO TITÃ
Pronto: cenários 3D, personagem Cibito, 11 planos (acordar, tropeçar, procurar pessoas, sol, regenerar, nuca, soldados, Titã anormal, correr/saltar, pôr do sol, sem controle), legendas coloridas.
Falta: renderizar os quadros finais, gerar o MP4 e conferir.
Pontos para revisar na prévia: (1) no tropeço o gigante sai um pouco do quadro; (2) conferir se o rosto do Cibito está igual a referencia-cibito.png (sobrancelhas e franja); (3) o Titã anormal sai parcialmente do quadro no salto.
Sem áudio ainda: os tempos das legendas são estimados pelo tamanho do texto.

## CIBITO (igual à imagem de referência)
Pele #f6c8a0 · cabelo cacheado #3a1f14 · capuz marrom #b5651d com orelhas, focinho de porquinho e abas laterais · camiseta preta #1c1620 · olhos grandes com pupila preta · contorno preto grosso.

## ROTEIRO DO TITÃ (narração — 11 trechos)
1. Imagine que você acordasse um dia e descobrisse que virou um Titã de Attack on Titan!
2. Primeiro, você teria um pequeno problema: seu corpo seria enorme, seus movimentos seriam desajeitados e você passaria mais tempo tropeçando do que andando.
3. Mas não seria só isso! Como Titã comum, você praticamente perderia sua inteligência humana. Sua única obsessão seria procurar pessoas por perto.
4. E sabe o pior? Você nem precisaria comer para sobreviver! Seu corpo conseguiria funcionar usando a energia do sol.
5. Mas existe uma vantagem: se alguém machucasse seu braço ou sua perna, seu corpo conseguiria regenerar o ferimento.
6. Só que nem tudo são flores... Os humanos conheceriam seu ponto fraco: a nuca.
7. E eles usariam equipamentos especiais para enfrentar criaturas gigantes como você.
8. E se você encontrasse um Titã Anormal?
9. Aí a situação ficaria ainda mais estranha, porque alguns deles conseguem correr, saltar e agir de maneiras completamente imprevisíveis.
10. No final, você descobriria que ser um Titã parece incrível...
11. até perceber que virou uma criatura gigante sem controle sobre a própria vida!

## VÍDEOS JÁ PRONTOS (baixe separadamente — são grandes)
jorisvaldo-sexta13-3d.mp4 (139 MB, 2:35) · jorisvaldo-90s-sincronizado.mp4 · jorisvaldo-90s.mp4 · ultimo-homem-sincronizado.mp4 · teste-pizzaria-3d.mp4
