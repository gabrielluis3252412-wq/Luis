const rnd=(i,a)=>Math.abs(sn(i*a+a)*43758.5453)%1;
const KW=(i,w,f=.5)=>{const p=PLAIN[i].indexOf(w);return SP[i][0]+(SP[i][1]-SP[i][0])*((p<0?0:p)+w.length*f)/PLAIN[i].length};
const UW=(i,w,f=.5)=>(KW(i,w,f)-SH[i].t0)/(SH[i].t1-SH[i].t0);
const MD=(u,a)=>{let m=a[0][1];for(const[x,k]of a)if(u>=x)m=k;return m};
const VO=t=>{for(let i=0;i<SP.length;i++)if(t>=SP[i][0]&&t<=SP[i][1]){for(const[a,b]of INT[i])if(t>=a-.04&&t<=b+.04)return .15;return 1}return 0};
const foc=(pt,z,ty=1000)=>{const S=1+z*1.06;return[540-(540+(pt[0]-540)*S),ty-(1000+(pt[1]-1000)*S)]};
const kf=(u,z,pt,ty,r,c)=>{const p=pt?foc(pt,z,ty==null?1000:ty):[0,0];return[u,z,p[0],p[1],r||0,c]};
const k0=(u,z,px,py,r,c)=>[u,z,px||0,py||0,r||0,c];
const scr=(x,y,z,sc=5.5,loc=0)=>{const P=CSH.pl,p=pj(P.VP,x,y,z),ku=.0046*(H/2)/(P.tf*p[2])*sc*(PLS[CSH.plate]||1);return[p[0],p[1]+loc*ku,ku]};
const cam=K=>{let i=0;while(i<K.length-1&&CU>=K[i+1][0])i++;const a=K[i],b=K[i+1];let v;
 if(!b||b[5]==='c')v=a.slice(1,5);else{const w=ez((CU-a[0])/(b[0]-a[0]));v=[1,2,3,4].map(j=>lp(a[j],b[j],w))}
 if(a[5]==='c'){const dt=(CU-a[0])*DD();if(dt<.2)v[0]+=.05*(1-dt/.2)**2}
 const z=v[0],mx=Math.max(0,540*z-16),my0=-Math.max(0,920*z-16),my1=Math.max(0,1000*z-16);
 FX.cz=z;FX.cpn=[Math.max(-mx,Math.min(mx,v[1])),Math.max(my0,Math.min(my1,v[2]))];FX.roll=v[3]};
const zp=(x,y,f=1.06)=>{const z0=FX.cz||0,pn=FX.cpn||[0,0];return[540+(x-540)*(1+z0*f)+pn[0],1000+(y-1000)*(1+z0*f)+pn[1]]};
const MD2=(u,a)=>MD(u,a);
const BURST=(t,t0,x,y,o={})=>{const d=t-t0,life=o.life||.8;if(d<0||d>life)return'';const n=o.n||14,sp=o.sp||420,r0=o.r||12,col=o.col||'#fff',k=d/life;let s='';
 for(let i=0;i<n;i++){const a=rnd(i,12.9)*6.283,v=sp*(.4+.6*rnd(i,78.2)),px=x+cs(a)*v*d*(1-.5*k),py=y+sn(a)*v*d*(1-.5*k)+(o.grav?700*d*d:0),r=Math.max(0,r0*(1-k)*(.6+.8*rnd(i,5.5)));
  s+=`<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="${r.toFixed(1)}" fill="${col}" stroke="${INK}" stroke-width="3" opacity="${(1-k*k).toFixed(2)}"/>`}return s};
const RING=(t,t0,x,y,R=300,life=.5,col='#fff')=>{const d=t-t0;if(d<0||d>life)return'';const k=d/life;return`<ellipse cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" rx="${(R*k).toFixed(1)}" ry="${(R*k*.3).toFixed(1)}" fill="none" stroke="${col}" stroke-width="${(14*(1-k)+2).toFixed(1)}" opacity="${(1-k).toFixed(2)}"/>`};
const RAYS=(t,t0,x,y,life=.35,n=16,col='#fff')=>{const d=t-t0;if(d<0||d>life)return'';const k=d/life;let s='';for(let i=0;i<n;i++){const a=i/n*6.283+rnd(i,3.3)*.3,r1=90+260*k,r2=r1+160*(1-k)+30,l=`x1="${(x+cs(a)*r1).toFixed(1)}" y1="${(y+sn(a)*r1).toFixed(1)}" x2="${(x+cs(a)*r2).toFixed(1)}" y2="${(y+sn(a)*r2).toFixed(1)}"`;s+=`<line ${l} stroke="${INK}" stroke-width="22" stroke-linecap="round" opacity="${(1-k).toFixed(2)}"/><line ${l} stroke="${col}" stroke-width="11" stroke-linecap="round" opacity="${(1-k).toFixed(2)}"/>`}return s};
const SPEED=(t,a=.5,col='#fff')=>{let s='';for(let i=0;i<30;i++){const an=rnd(i,9.1)*6.283,ph=(t*3.2+rnd(i,4.2))%1,r1=520+rnd(i,7.7)*120+ph*60,L=130+rnd(i,2.2)*170;s+=`<line x1="${(540+cs(an)*r1).toFixed(1)}" y1="${(1000+sn(an)*r1*1.5).toFixed(1)}" x2="${(540+cs(an)*(r1-L)).toFixed(1)}" y2="${(1000+sn(an)*(r1-L)*1.5).toFixed(1)}" stroke="${col}" stroke-width="${(5+rnd(i,6)*6).toFixed(1)}" stroke-linecap="round" opacity="${(a*(.5+.5*rnd(i,1.1))).toFixed(2)}"/>`}return s};
const STEAM=(t,x,y,a=1,n=6)=>{let s='';for(let i=0;i<n;i++){const ph=(t*.9+i/n)%1;s+=`<circle cx="${(x+16*sn(ph*9+i)).toFixed(1)}" cy="${(y-ph*190).toFixed(1)}" r="${(10+ph*26).toFixed(1)}" fill="#fff" stroke="${INK}" stroke-width="3" opacity="${((1-ph)*.85*a).toFixed(2)}"/>`}return s};
const HEAD=(rot)=>{const s=CHS.CIB.sp,a=rot*Math.PI/180,L=232*s[2];return[s[0]+L*sn(a),s[1]-L*cs(a)]};
const GL=(x,y,r,col,a)=>[x,y,r,col,a];
const TDUR=.22;
const trans=(gt,sh)=>{const R={dx:0,dy:0,s:1,bx:0,by:0,fl:0,col:'255,255,255',r:0};const i=SH.indexOf(sh),nx=SH[i+1];
 const ap=(type,p,io)=>{const e=p*p;
  if(type=='wl'||type=='wr'){const dr=(type=='wl'?-1:1)*(io=='out'?1:-1);R.s=1+.34*e;R.dx=dr*e*170;R.bx=e*46;R.r=dr*e*1.4}
  else if(type=='zoom'){R.s=1+.5*e;R.bx=R.by=e*10}
  else if(type=='flash'||type=='flashO'){R.s=1+.08*e;R.fl=Math.min(.95,e*1.1);R.col=type=='flashO'?'255,170,90':'255,255,255';R.bx=R.by=e*5}
  else if(type=='dip'){R.fl=e*.85;R.col='5,0,15'}};
 const ti=gt-sh.t0;if(sh.tin&&ti<TDUR)ap(sh.tin,1-ti/TDUR,'in');
 if(nx&&nx.tin&&gt>sh.t1-TDUR)ap(nx.tin,(gt-(sh.t1-TDUR))/TDUR,'out');return R};
document.body.insertAdjacentHTML('beforeend','<svg width="0" height="0" style="position:absolute"><filter id="mbx" x="-30%" y="-10%" width="160%" height="120%"><feGaussianBlur id="mbg" stdDeviation="0 0"/></filter></svg>');
