import os,sys
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
from PIL import Image
sel=[(int(a.split(':')[0]),float(a.split(':')[1])) for a in sys.argv[1:]]
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':1080,'height':1920})
    pg.on('pageerror',lambda e:print('ERR',e))
    pg.goto('file:///home/claude/titan/story.html')
    sh=pg.evaluate('SH.map(s=>[s.t0,s.t1])');ims=[]
    for i,u in sel:
        t0,t1=sh[i];pg.evaluate(f"F({t0+(t1-t0)*u})");pg.screenshot(path='_t.jpg',type='jpeg',quality=85);ims.append(Image.open('_t.jpg').resize((360,640)))
    b.close()
n=len(ims);W=min(n,5);sheet=Image.new('RGB',(360*W,640*((n+W-1)//W)))
for k,im in enumerate(ims):sheet.paste(im,((k%W)*360,(k//W)*640))
sheet.save('pvt.jpg',quality=88)
