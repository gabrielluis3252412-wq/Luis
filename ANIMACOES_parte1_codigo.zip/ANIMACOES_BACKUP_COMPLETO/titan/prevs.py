import os,sys
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={'width':1080,'height':1920})
    pg.on('pageerror',lambda e:print('ERR',e));pg.on('console',lambda m:print('LOG',m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/titan/story.html')
    print('total',pg.evaluate('TOTAL'))
    shots=pg.evaluate('SH.map(s=>[s.plate,s.t0,s.t1])')
    n=0
    sel=[int(x) for x in sys.argv[1:]] or range(len(shots))
    for i in sel:
        pl,t0,t1=shots[i];t=t0+(t1-t0)*.55
        pg.evaluate(f"F({t})");pg.screenshot(path=f'/home/claude/titan/pv_{i:02d}.jpg',type='jpeg',quality=85)
    b.close()
print(len(shots))
