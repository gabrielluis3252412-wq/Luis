#!/bin/bash
cd /home/claude/titan
n=$(python3 -c "import json;print(len(json.load(open('todo.json'))))")
s=0
while [ $s -lt $n ]; do
  timeout 140 python3 rr.py run $s $((s+100)) >> rr.log 2>&1 && s=$((s+100))
done
echo ALLDONE >> rr.log
