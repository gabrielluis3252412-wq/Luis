#!/bin/bash
cd /home/claude/titan
while true; do
  last=$(ls frames5 | tail -1 | sed 's/.jpg//' | sed 's/^0*//')
  [ -z "$last" ] && last=-1
  if [ $last -ge 2135 ]; then break; fi
  rm -f frames5/$(printf '%05d' $last).jpg
  s=$last
  [ $s -lt 0 ] && s=0
  if [ $s -ge 2130 ]; then break; fi
  timeout 150 python3 rec_resume.py $s $((s+120)) >> chunks.log 2>&1
  echo "chunk from $s" >> chunks.log
done
echo ALLDONE >> chunks.log
