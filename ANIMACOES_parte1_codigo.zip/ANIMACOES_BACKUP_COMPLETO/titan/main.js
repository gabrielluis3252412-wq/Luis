const W=1080,H=1920,$=id=>document.getElementById(id),sn=Math.sin,cs=Math.cos,ab=Math.abs;
const cl=x=>x<0?0:x>1?1:x,ez=x=>{x=cl(x);return x*x*(3-2*x)},lp=(a,b,x)=>a+(b-a)*x;
const SEG=['Imagine que você acordasse um dia e descobrisse que virou um *Titã de Attack on Titan!*','Primeiro, você teria um pequeno problema: seu corpo seria *enorme,* seus movimentos seriam desajeitados e você passaria mais tempo *tropeçando* do que andando.','Mas não seria só isso! Como Titã comum, você praticamente perderia sua *inteligência* humana. Sua única obsessão seria procurar *pessoas* por perto.','E sabe o pior? Você nem precisaria comer para sobreviver! Seu corpo conseguiria funcionar usando a energia do *sol.*','Mas existe uma vantagem: se alguém machucasse seu braço ou sua perna, seu corpo conseguiria *regenerar* o ferimento.','Só que nem tudo são flores... Os humanos conheceriam seu ponto fraco: a *nuca.*','E eles usariam *equipamentos especiais* para enfrentar criaturas gigantes como você.','E se você encontrasse um Titã *Anormal?*','Aí a situação ficaria ainda mais estranha, porque alguns deles conseguem *correr, saltar* e agir de maneiras completamente *imprevisíveis.*','No final, você descobriria que ser um Titã parece incrível...','até perceber que virou uma criatura gigante sem *controle* sobre a própria vida!'];
const SS=[0.5, 5.748, 17.288, 27.282, 35.901, 43.532, 48.767, 55.025, 57.826, 67.142, 71.245, 76.54],SP=[[0.55, 5.513], [5.984, 17.084], [17.491, 27.096], [27.468, 35.663], [36.139, 43.31], [43.753, 48.571], [48.962, 54.781], [55.268, 57.594], [58.058, 66.941], [67.342, 71.032], [71.458, 76.45]],INT=[[], [[8.193, 8.593], [10.361, 10.692]], [[18.809, 19.217], [23.166, 23.535]], [[28.163, 28.578], [31.24, 31.628]], [[37.648, 38.018], [40.416, 40.702]], [[45.801, 46.203]], [[49.579, 49.938]], [], [], [], []];const TOTAL=SS[11]+1.0;
const at=x=>{const i=Math.floor(x+1e-9),f=x-i;return SS[i]+f*(SS[i+1]-SS[i])};
const PLAIN=SEG.map(t=>t.replace(/\*/g,'')),QS={},mouthAt=()=>({o:0,w:0,on:0});
const EMP=[];SEG.forEach((t,i)=>{let pos=0;const P=PLAIN[i].length,dur=SP[i][1]-SP[i][0];t.split('*').forEach((p,j)=>{if(j%2)EMP.push(SP[i][0]+dur*(pos+p.length/2)/P);pos+=p.length})});
const emph=t=>EMP.reduce((mx,h)=>Math.max(mx,Math.exp(-((t-h)**2)/.07)),0);
window.TOTAL=TOTAL;window.SEGT=SEG.map((t,i)=>[t,SS[i],SS[i+1]]);window.SPEECH=SEG.map((t,i)=>[t,SP[i][0],SP[i][1],INT[i]]);
const ST=(sz)=>`stroke="${INK}" stroke-width="${sz*.16}" paint-order="stroke" stroke-linejoin="round"`;
const TXT=(s,x,y,sz,c,rot=0,sc=1)=>`<text x="0" y="0" transform="translate(${x} ${y}) rotate(${rot}) scale(${sc})" font-size="${sz}" text-anchor="middle" fill="${c}" ${ST(sz)} font-family="Poppins,Arial Black,sans-serif" font-weight="800">${s}</text>`;
const S4=S.replace('"7"','"4"');
const HOOD=`<path d="M-62-250C-92-236-94-176-84-146Q-70-134-58-146C-54-186-58-226-58-246Z" fill="#b5651d" ${S}/><path d="M62-250C92-236 94-176 84-146Q70-134 58-146C54-186 58-226 58-246Z" fill="#b5651d" ${S}/><g transform="translate(0 -18)"><path d="M-72-238C-80-332 80-332 72-238Q0-258-72-238Z" fill="#b5651d" ${S}/><path d="M-60-292L-76-348L-30-318Z" fill="#b5651d" ${S}/><path d="M-58-300L-66-332L-40-316Z" fill="#f0a98a"/><path d="M60-292L76-348L30-318Z" fill="#b5651d" ${S}/><path d="M58-300L66-332L40-316Z" fill="#f0a98a"/><path d="M-16-316L-8-340L0-322L10-344L18-316Z" fill="#3a1f14" ${S4}/><ellipse cy="-284" rx="34" ry="22" fill="#f6c8a0" ${S}/><ellipse cx="-11" cy="-286" rx="4.5" ry="6" fill="#1b1024"/><ellipse cx="11" cy="-286" rx="4.5" ry="6" fill="#1b1024"/>${[-44,-24,-4,16,36].map((x,i)=>`<circle cx="${x}" cy="${-238+(i%2)*4}" r="12" fill="#3a1f14" ${S4}/>`).join('')}</g>${[[-80,-212],[-84,-192],[80,-212],[84,-192]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="10" fill="#3a1f14" ${S4}/>`).join('')}`;
const CHD={CIB:{sk:'#f6c8a0',hc:'#3a1f14',hs:'short',sh:'#1c1620',pa:'#2b2b3a',ic:'#111',hat:HOOD,id:1},T1:{sk:'#e8b088',hc:'#222',hs:'short',sh:'#ff5d8f',pa:'#3a3f7a',ic:'#4a2c1a',id:2},T2:{sk:'#8d5a3a',hc:'#111',hs:'curly',sh:'#2ec4b6',pa:'#3a3f7a',ic:'#333',id:3},T3:{sk:'#f6c9a0',hc:'#d9892b',hs:'long',sh:'#ffbe0b',pa:'#7b5cff',ic:'#2b6',id:4},S1:{sk:'#e8b088',hc:'#3a2a1a',hs:'short',sh:'#5a7a3a',pa:'#6b4a2a',ic:'#333',id:5},S2:{sk:'#c98b5b',hc:'#111',hs:'short',sh:'#5a7a3a',pa:'#6b4a2a',ic:'#333',id:6},S3:{sk:'#f6c9a0',hc:'#7a3b1d',hs:'short',sh:'#5a7a3a',pa:'#6b4a2a',ic:'#2b6',id:7},AB:{sk:'#d9e8c0',hc:'#3d3d2a',hs:'short',sh:'#8d8d95',pa:'#6a6a78',ic:'#e8ff7a',id:8}};
const CHS={},cw=$('cw'),cwR=$('cwR'),oc=$('O').getContext('2d');const mkg=()=>{const g=document.createElementNS('http://www.w3.org/2000/svg','g');g.innerHTML='<g class="in"></g><g class="ex"></g>';cw.appendChild(g);return{g,in:g.firstChild,ex:g.lastChild,key:''}};
for(const k in CHD)CHS[k]={...mkg(),d:CHD[k],id:CHD[k].id};['C','C2'].forEach(k=>CHS[k]={...mkg(),d:null,id:99});
const PLS={bed:1.2,twn:1,twn2:1},PLC={},GT0=0;let CSH=null,GT=0,FR=[],FX={},CU=0;
const getPl=k=>{if(!PLC[k]){const c=PLATES[k].cam,VP=mul(persp(c.fov,W/H,.1,90),look(c.eye,c.tg));PLC[k]={VP,tf:Math.tan(c.fov/2),cam:c}}return PLC[k]};
let SHD=[];
function put(k,x,y,z,o={}){const C=CHS[k],P=CSH.pl,t=GT,id=C.id,p=o.px?[o.px[0],o.px[1],1]:pj(P.VP,x,y,z),ku=o.ku||.0046*(H/2)/(P.tf*p[2])*(o.sc||1)*(PLS[CSH.plate]||1),lm=mouthAt(k,t),spk=lm.on||(o.talk>0)?1:0;
 let mood=o.m||'happy';if(spk&&o.mt)mood=o.mt;const key=[mood,o.fr||'',o.hold?1:0,o.pd?o.pd.join():''].join('|');
 if(C.key!=key){C.key=key;C.in.innerHTML=ch({...C.d,m:mood,front:o.fr,hold:o.hold,walk:1,pd:o.pd});const q=n=>$(n+id);C.el={aR:q('aR'),aL:q('aL'),lgL:q('lgL'),lgR:q('lgR'),mo:q('mo'),bl:q('bl'),hd:q('hd'),bw:q('bw'),hg:q('hg'),bd:q('bd'),pp:C.g.querySelectorAll('.pp')}}
 const e=C.el,em=emph(t),g=Math.max(spk,(id==1&&o.vo!==0)?VO(t)*.85:0)*(o.gest??1);
 e.aR&&(e.aR.style.transform=`rotate(${o.aR??(sn(t*1.6+id)*3+g*13*sn(t*4.1+id*2)+em*9)}deg)`);e.aL&&(e.aL.style.transform=`rotate(${o.aL??(sn(t*1.4+id)*-3-g*13*sn(t*3.7+id*3)-em*9)}deg)`);
 const LGv=o.lg!=null?o.lg:2.2*sn(t*1.1+id);e.lgL&&(e.lgL.style.transform=`rotate(${LGv}deg)`);e.lgR&&(e.lgR.style.transform=`rotate(${-LGv}deg)`);
 if(e.mo){let ry=3,rx=14;if(o.mry!=null){ry=o.mry;rx=o.mrx||14}else if(lm.on){ry=3+lm.o*14*(o.msc||1);rx=14+lm.w*5}else if(o.talk>0){ry=3+o.talk*11*ab(sn(t*13+id*2));rx=14+o.talk*2}e.mo.setAttribute('ry',ry.toFixed(1));e.mo.setAttribute('rx',rx.toFixed(1))}
 const bp=3.1+.53*id,bph=((t+id*1.7)%bp)/bp;e.bl&&(e.bl.style.transform=`scaleY(${bph>.962?.1:1})`);
 e.bw&&e.bw.setAttribute('transform',`translate(0 ${(-em*9-(o.brow||0)+(spk?2*sn(t*5+id):0)).toFixed(1)})`);
 if(e.hg){e.hg.style.transformOrigin='0px -186px';e.hg.style.transform=`rotate(${(3*sn(t*.9+id)+2*sn(t*2.3+id*2)*(spk?1:.3)+em*3+(o.tilt||0)).toFixed(2)}deg)`}
 e.bd&&(e.bd.style.transform=`scale(${1+.011*sn(t*1.9+id)})`);
 e.pp&&e.pp.forEach(q=>q.setAttribute('transform',`translate(${(1.5*sn(t*.9+id*3)+(o.look?o.look[0]:0)).toFixed(1)} ${(sn(t*1.3+id)+(o.look?o.look[1]:0)).toFixed(1)})`));
 if(e.hd&&o.hs!=null)e.hd.setAttribute('transform',`scale(1,${o.hs})`);C.ex.innerHTML=o.extra||'';
 const bob=o.bobv!=null?o.bobv:(o.nobob?0:sn(t*3.2+id)*2*(o.bob||1));
 C.g.setAttribute('transform',`translate(${(p[0]+(o.nodrift?0:6*sn(t*.8+id*2))).toFixed(1)} ${(p[1]+bob).toFixed(1)}) scale(${(ku*(o.flip||1)*(o.sx||1)*(1+.03*em)).toFixed(4)} ${(ku*(o.sy||1)*(1-.025*em)).toFixed(4)}) rotate(${o.rot!=null?o.rot:1.3*sn(t*.9+id)}) ${o.sit?'translate(0 90)':''}`);C.g.style.display='';C.z=p[2];C.k=k;C.sp=[p[0],p[1],ku];FR.push(C);if(!o.sit&&!o.px&&y<.4)SHD.push([p[0],p[1],ku])}
function sprite(svg,x,y,sc,z,sl='C'){const C=CHS[sl];C.in.innerHTML=svg;C.g.setAttribute('transform',`translate(${x} ${y}) scale(${sc})`);C.g.style.display='';C.z=z;C.k='C';FR.push(C)}
const sh1=(t,tm,dk=6)=>{let m=0;tm.forEach(b=>{const d=t-b;if(d>=0)m=Math.max(m,Math.exp(-d*dk))});return m};
const pop=(t,b)=>{const d=t-b;return d<0?0:1+.35*Math.exp(-d*7)*cs(d*30)};
const GLW={bed:[[-1.9,2.2,-3.4,1.8,'255,240,200',.4],[1.8,1.3,-3,.9,'255,180,80',.5]],twn:[[14,26,-90,14,'255,250,200',.5]],twn2:[[0,7,-85,20,'255,150,70',.6]]},EXT={},NOD={twn:1,twn2:1},STARS=[],BEAMS={bed:[[-2.5,3.0,-3.4],[-1.3,1.4,-3.4],[.5,0,-1.2],[-2.2,0,-.8]]};
const walk=(t,s=10)=>({lg:34*sn(t*s),aR:-30*sn(t*s),aL:30*sn(t*s),rot:2*sn(t*s*.5),bobv:-7*ab(sn(t*s))});
const hand=(k,sd,deg)=>{const C=CHS[k].sp,a=deg*Math.PI/180,vx=sd*30.8,vy=66,x=sd*44+vx*Math.cos(a)-vy*Math.sin(a),y=-170+vx*Math.sin(a)+vy*Math.cos(a);return[C[0]+x*C[2],C[1]+y*C[2]]};
const DUST=a=>`<g opacity="${1-a}">${[-90,-45,0,45,90].map((x,i)=>`<circle cx="${x*(1+a)}" cy="${-20-a*50-(i%2)*14}" r="${26+a*46}" fill="#f4e4c8" stroke="${INK}" stroke-width="4"/>`).join('')}</g>`;
const BACKX=t=>`<circle cy="-235" r="68" fill="#3a1f14" ${S}/><path d="M-62-250C-92-236-94-176-84-146Q-70-134-58-146C-54-186-58-226-58-246Z" fill="#b5651d" ${S}/><path d="M62-250C92-236 94-176 84-146Q70-134 58-146C54-186 58-226 58-246Z" fill="#b5651d" ${S}/><g transform="translate(0 -18)"><path d="M-72-238C-80-332 80-332 72-238Q0-258-72-238Z" fill="#b5651d" ${S}/><path d="M-60-292L-76-348L-30-318Z" fill="#b5651d" ${S}/><path d="M60-292L76-348L30-318Z" fill="#b5651d" ${S}/></g><g transform="translate(0 -176)"><circle r="${17+4*sn(t*6)}" fill="none" stroke="#ff2d3a" stroke-width="7"/><path d="M-28 0H28M0-28V28" stroke="#ff2d3a" stroke-width="7"/></g>`;
const run=(k,x0,x1,z,t,u,u0,u1)=>{const w=(u-u0)/(u1-u0);if(w>0&&w<1)put(k,lp(x0,x1,w),0,z,{m:'scared',...walk(t,10)})};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const rnd=(i,a)=>Math.abs(sn(i*a+a)*43758.5453)%1;
const KW=(i,w,f=.5)=>{const p=PLAIN[i].indexOf(w);return SP[i][0]+(SP[i][1]-SP[i][0])*((p<0?0:p)+w.length*f)/PLAIN[i].length};
const UW=(i,w,f=.5)=>(KW(i,w,f)-SH[i].t0)/(SH[i].t1-SH[i].t0);
const MD=(u,a)=>{let m=a[0][1];for(const[x,k]of a)if(u>=x)m=k;return m};
const VO=t=>{for(let i=0;i<SP.length;i++)if(t>=SP[i][0]&&t<=SP[i][1]){for(const[a,b]of INT[i])if(t>=a-.04&&t<=b+.04)return .15;return 1}return 0};
const foc=(pt,z,ty=1000)=>{const S=1+z*1.06;return[540-(540+(pt[0]-540)*S),ty-(1000+(pt[1]-1000)*S)]};
const kf=(u,z,pt,ty,r,c)=>{const p=pt?foc(pt,z,ty==null?1000:ty):[0,0];return[u,z,p[0],p[1],r||0,c]};
const k0=(u,z,px,py,r,c)=>[u,z,px||0,py||0,r||0,c];
const scr=(x,y,z,sc=5.5,loc=0)=>{const P=CSH.pl,p=pj(P.VP,x,y,z),ku=.0046*(H/2)/(P.tf*p[2])*sc*(PLS[CSH.plate]||1);return[p[0],p[1]+loc*ku,ku]};
const cam=K=>{let i=0;while(i<K.length-1&&CU>=K[i+1][0])i++;const a=K[i],b=K[i+1];let v;
 if(!b||b[5]==='c')v=a.slice(1,5);else{const w=ez((CU-a[0])/(b[0]-a[0]));v=[1,2,3,4].map(j=>lp(a[j],b[j],w))}
 if(a[5]==='c'){const dt=(CU-a[0])*DD();if(dt<.2)v[0]+=.05*(1-dt/.2)**2}
 const z=Math.max(v[0],.012+.034*Math.abs(v[3])),mx=Math.max(0,540*z-16),my0=-Math.max(0,920*z-16),my1=Math.max(0,1000*z-16);
 FX.cz=z;FX.cpn=[Math.max(-mx,Math.min(mx,v[1])),Math.max(my0,Math.min(my1,v[2]))];FX.roll=v[3]};
const zp=(x,y,f=1.06)=>{const z0=FX.cz||0,pn=FX.cpn||[0,0];return[540+(x-540)*(1+z0*f)+pn[0],1000+(y-1000)*(1+z0*f)+pn[1]]};
const MD2=(u,a)=>MD(u,a);
const BURST=(t,t0,x,y,o={})=>{const d=t-t0,life=o.life||.8;if(d<0||d>life)return'';const n=o.n||14,sp=o.sp||420,r0=o.r||12,col=o.col||'#fff',k=d/life;let s='';
 for(let i=0;i<n;i++){const a=rnd(i,12.9)*6.283,v=sp*(.4+.6*rnd(i,78.2)),px=x+cs(a)*v*d*(1-.5*k),py=y+sn(a)*v*d*(1-.5*k)+(o.grav?700*d*d:0),r=Math.max(0,r0*(1-k)*(.6+.8*rnd(i,5.5)));
  s+=`<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="${r.toFixed(1)}" fill="${col}" stroke="${INK}" stroke-width="3" opacity="${(1-k*k).toFixed(2)}"/>`}return s};
const RING=(t,t0,x,y,R=300,life=.5,col='#fff')=>{const d=t-t0;if(d<0||d>life)return'';const k=d/life;return`<ellipse cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" rx="${(R*k).toFixed(1)}" ry="${(R*k*.3).toFixed(1)}" fill="none" stroke="${col}" stroke-width="${(14*(1-k)+2).toFixed(1)}" opacity="${(1-k).toFixed(2)}"/>`};
const RAYS=(t,t0,x,y,life=.35,n=16,col='#fff')=>{const d=t-t0;if(d<0||d>life)return'';const k=d/life;let s='';for(let i=0;i<n;i++){const a=i/n*6.283+rnd(i,3.3)*.3,r1=90+260*k,r2=r1+160*(1-k)+30,l=`x1="${(x+cs(a)*r1).toFixed(1)}" y1="${(y+sn(a)*r1).toFixed(1)}" x2="${(x+cs(a)*r2).toFixed(1)}" y2="${(y+sn(a)*r2).toFixed(1)}"`;s+=`<line ${l} stroke="${INK}" stroke-width="22" stroke-linecap="round" opacity="${(1-k).toFixed(2)}"/><line ${l} stroke="${col}" stroke-width="11" stroke-linecap="round" opacity="${(1-k).toFixed(2)}"/>`}return s};
const SPEED=(t,a=.5,col='#fff')=>{let s='';for(let i=0;i<30;i++){const an=rnd(i,9.1)*6.283,ph=(t*3.2+rnd(i,4.2))%1,r1=520+rnd(i,7.7)*120+ph*60,L=130+rnd(i,2.2)*170;s+=`<line x1="${(540+cs(an)*r1).toFixed(1)}" y1="${(1000+sn(an)*r1*1.5).toFixed(1)}" x2="${(540+cs(an)*(r1-L)).toFixed(1)}" y2="${(1000+sn(an)*(r1-L)*1.5).toFixed(1)}" stroke="${col}" stroke-width="${(5+rnd(i,6)*6).toFixed(1)}" stroke-linecap="round" opacity="${(a*(.5+.5*rnd(i,1.1))).toFixed(2)}"/>`}return s};
const STEAM=(t,x,y,a=1,n=6)=>{let s='';for(let i=0;i<n;i++){const ph=(t*.9+i/n)%1;s+=`<circle cx="${(x+16*sn(ph*9+i)).toFixed(1)}" cy="${(y-ph*190).toFixed(1)}" r="${(10+ph*26).toFixed(1)}" fill="#fff" stroke="${INK}" stroke-width="3" opacity="${((1-ph)*.85*a).toFixed(2)}"/>`}return s};
const HEAD=(rot)=>{const s=CHS.CIB.sp,a=rot*Math.PI/180,L=232*s[2];return[s[0]+L*sn(a),s[1]-L*cs(a)]};
const GL=(x,y,r,col,a)=>[x,y,r,col,a];
const TDUR=.22;
const trans=(gt,sh)=>{const R={dx:0,dy:0,s:1,bx:0,by:0,fl:0,col:'255,255,255',r:0};const i=SH.indexOf(sh),nx=SH[i+1];
 const ap=(type,p,io)=>{const e=p*p;
  if(type=='wl'||type=='wr'){const dr=(type=='wl'?-1:1)*(io=='out'?1:-1);R.s=1+.34*e;R.dx=dr*e*170;R.bx=e*46;R.r=dr*e*1.4}
  else if(type=='zoom'){R.s=1+.5*e;R.bx=R.by=e*10}
  else if(type=='flash'||type=='flashO'){R.s=1+.08*e;R.fl=Math.min(.95,e*1.1);R.col=type=='flashO'?'255,170,90':'255,255,255';R.bx=R.by=e*5}
  else if(type=='dip'){R.fl=e*.85;R.col='5,0,15'}};
 const ti=gt-sh.t0;if(sh.tin&&ti<TDUR)ap(sh.tin,1-ti/TDUR,'in');
 if(nx&&nx.tin&&gt>sh.t1-TDUR)ap(nx.tin,(gt-(sh.t1-TDUR))/TDUR,'out');return R};
document.body.insertAdjacentHTML('beforeend','<svg width="0" height="0" style="position:absolute"><filter id="mbx" x="-30%" y="-10%" width="160%" height="120%"><feGaussianBlur id="mbg" stdDeviation="0 0"/></filter></svg>');

const SH=[];const shot=(plate,a,b,f,tin)=>SH.push({plate,t0:at(a),t1:at(b),f,tin}),G=o=>({sc:5.5,...o}),DD=()=>CSH.t1-CSH.t0;
shot('bed',0,1,(t,u)=>{
 const d=DD(),sl=u<.26,yw=ez((u-.26)/.07)*(1-ez((u-.46)/.07)),st=ez((u-.40)/.12)*(1-ez((u-.70)/.05)),lk=u>=.76,tS=.76*d;
 const f=scr(0,.85,-2.6,1,-142);
 put('CIB',0,.85,-2.6,{sit:1,m:sl?'sleepy':lk?'shock':yw>.02?'talka':'happy',mry:yw>.02?3+yw*22:undefined,mrx:yw>.02?16:undefined,aR:st*-150,aL:st*150,brow:lk?8:0,tilt:sl?9*sn(t*2):-4*yw,look:lk?[0,6]:[0,0],nobob:sl,sy:1+.012*sn(t*2.2)+.045*yw+.03*st,vo:0});
 cam([kf(0,.36,f,880,-1.5),kf(.24,.13,f,1000,0),kf(.3,.13,f,1000,0),kf(.46,.3,f,920,1.2),kf(.5,.3,f,920,1.2),kf(.64,.1,f,1000,0),kf(.72,.1,f,1000,0),kf(.76,.4,f,860,0,'c'),kf(1,.47,f,860,0)]);
 FX.shake=15*sh1(t,[tS],6);FX.gl=lk?[[540,860,760,'255,235,190',.75*sh1(t,[tS],8)]]:null;
 const zf=zp(f[0],f[1]);
 FX.ui=(sl?[0,1,2].map(i=>{const ph=(t*.45+i/3)%1;return`<g opacity="${(Math.min(1,ph*8)*(1-ph)).toFixed(2)}">`+TXT('Z',zf[0]+110+ph*70+i*14,zf[1]-70-ph*300,56+ph*60,'#9ad0ff',8,1)+'</g>'}).join(''):'')+(lk?RAYS(t,tS,540,860,.4,18)+TXT('TITÃ?!',540,300,170,'#ffd23f',-4,pop(t,tS)):'')
},null);
shot('twn',1,2,(t,u)=>{
 const d=DD(),uE=UW(1,'enorme',.6),uD=UW(1,'desajeitados',.3),uT=UW(1,'tropeçando',.25),uU=UW(1,'andando',.15);
 const P1=u<uE-.02,P2=!P1&&u<uD-.03,P3=!P1&&!P2&&u<uT,P4=u>=uT&&u<uU;
 const w=cl(u/(uE-.02)),wb=ez((u-uD+.03)/.05)*(1-ez((u-uT)/.02)),tp=ez((u-uT)/.03),up=ez((u-uU)/.1),fall=tp*(1-up);
 const x0=lp(-2.4,.4,ez(w))+lp(0,1.5,ez((u-uD)/(uT-uD)))*(u<uU?1:0)+(u>=uU?lp(1.5,0,ez((u-uU)/.06)):0)+(P3?.1*sn(t*3.1):0);
 let pz={m:'happy',...walk(t,10)};
 if(!P1)pz={m:'cool',aR:-62-10*sn(t*6),aL:62+10*sn(t*6),lg:0,rot:0,bobv:0,sy:1+.05*ez((u-uE+.02)/.03)*(1-ez((u-uE-.04)/.05))};
 if(P3)pz={m:'worry',aR:-20-80*sn(t*8)*wb,aL:20+80*sn(t*7)*wb,lg:28*sn(t*9)*wb,rot:9*sn(t*5)*wb,bobv:-5*ab(sn(t*9))*wb,brow:5};
 if(u>=uT)pz={m:P4?'scared':'blank',rot:-78*fall,aR:-130*fall-20*(1-fall),aL:130*fall+20*(1-fall),lg:0,brow:fall*8};
 put('CIB',x0,0,-3,G({sc:4.8,...pz}));
 const sp=CHS.CIB.sp;
 FX.shake=P1?6*Math.max(0,1-ab(sn(t*10))/.14):0;FX.shake=Math.max(FX.shake,16*sh1(t,[uE*d,uT*d+.05],7));
 cam([k0(0,.22,80,40,-.8),k0(uE-.02,.1,0,0,0),k0(uE+.06,.1,0,0,0),k0(uD-.03,.16,0,30,.8),k0(uT-.01,.2,0,60,-1),k0(uT+.05,.08,0,0,1.5),k0(uU,.08,0,0,0),k0(1,.12,0,20,0)]);
 if(u>uT&&u<uT+.12){const a=cl((u-uT)/.12);sprite(DUST(a),sp[0]+120,sp[1]-6,sp[2]*1.5,40,'C2')}
 run('T1',3.6,-3.8,3,t,u,uE-.05,uE+.28);run('T2',-3.8,3.8,3.6,t,u,uE,uE+.32);
 const z=zp(sp[0],sp[1]);let ui='';
 if(u>=uE-.02&&u<uE+.2)ui+=RING(t,(uE-.02)*d,z[0],z[1],420,.6,'#fff')+BURST(t,(uE-.02)*d,z[0],z[1]-10,{n:12,sp:520,r:14,col:'#f4e4c8',life:.6});
 if(u>=uT&&u<uT+.2)ui+=RING(t,uT*d,z[0]+150,z[1],480,.6,'#fff')+BURST(t,uT*d,z[0]+150,z[1]-10,{n:16,sp:620,r:16,col:'#f4e4c8',life:.7,grav:1});
 if(u>uT+.04&&u<uU){const h=zp(...HEAD(-78));[0,1,2].forEach(i=>{const a=t*5+i*2.1;ui+=TXT('⭐',h[0]+90*cs(a),h[1]-40+34*sn(a),64,'#ffd23f')})}
 FX.ui=ui;FX.tint=null
},'zoom');
shot('twn',2,3,(t,u)=>{
 const d=DD(),uI=UW(2,'inteligência',.4),uO=UW(2,'obsessão',.5),uP=UW(2,'pessoas',.4);
 const H1={a:uO-.04,b:Math.min(1,uO+.2)},H2={a:uO+.02,b:Math.min(1,uO+.24)},H3={a:uO+.08,b:Math.min(1,uO+.26)};
 const hx=(H,x0,x1)=>{const w=(u-H.a)/(H.b-H.a);return w>0&&w<1?lp(x0,x1,w):null};
 const hs=[hx(H1,3.8,-3.8),hx(H2,-3.8,3.8),hx(H3,3.8,-3.8)].filter(v=>v!=null),tx=hs.length?hs.reduce((a,b)=>ab(a)<ab(b)?a:b):0;
 const hung=u>=uO-.03,dumb=u>=uI+.05&&!hung;
 put('CIB',0,0,-3,G({sc:5,m:MD(u,[[0,'smirk'],[uI+.05,'blank'],[uO-.03,'awe']]),tilt:dumb?14*sn(t*1.6):(hung?-5*tx*.4:3*sn(t)),look:hung?[clamp(tx*4,-10,10),0]:(dumb?[9*sn(t*2.2),0]:[0,0]),rot:hung?clamp(tx*1.4,-6,6):1.3*sn(t*.9),
  aR:hung?-70-30*sn(t*5):(dumb?-55+8*sn(t*3):-25),aL:hung?70+30*sn(t*5.3):(dumb?55-8*sn(t*3.3):25),brow:hung?5:0,
  extra:dumb?`<path d="M12-190q${4+2*sn(t*3)} ${14+6*ab(sn(t*2))} 0 ${22+8*ab(sn(t*2))}q-4-10 0-22" fill="#9ad0ff" ${S4}/>`:''}));
 run('T1',3.8,-3.8,2.4,t,u,H1.a,H1.b);run('T2',-3.8,3.8,3.2,t,u,H2.a,H2.b);run('T3',3.8,-3.8,1.6,t,u,H3.a,H3.b);
 const hp=scr(0,0,-3,5,-232),bp0=scr(0,0,-3,5,-232),bp=[bp0[0]+270,bp0[1]-270];
 cam([k0(0,.0,0,0,1),k0(uI-.05,.1,0,20,0),k0(uI+.12,.16,0,50,-.8),k0(uO-.05,.08,0,20,.5),k0(uO+.1,.1,clamp(-tx*18,-40,40),20,-.5),k0(1,.14,0,30,.6)]);
 const bz=zp(bp[0],bp[1]);let ui='';
 if(u>=uI-.06&&u<uI+.07){const on=u<uI-.0?1:(Math.floor(t*18)%2?1:.15);ui+=`<g opacity="${on}">`+TXT('💡',bz[0],bz[1],150,'#fff',0,1)+'</g>';FX.gl=[[bz[0],bz[1],420,'255,230,120',.5*on]]}
 else if(u>=uI+.07&&u<uI+.2){const a=cl((u-uI-.07)/.13);ui+=`<g opacity="${1-a}">`+TXT('💨',bz[0]+60*a,bz[1]-40-80*a,130,'#fff')+'</g>'}
 if(dumb&&u>uI+.16)ui+=`<g opacity=".9">`+TXT('...',bz[0],bz[1]+30,120,'#fff')+'</g>';
 if(u>=uO-.03&&u<uO+.12){const a=ez((u-uO+.03)/.05);ui+=TXT('👀',bz[0],bz[1]+20,130*a,'#fff',-6,1)}
 FX.ui=ui
},'wl');
shot('twn',3,4,(t,u)=>{
 const d=DD(),uC=UW(3,'comer',.5),uS=UW(3,'sol',.4),uP=UW(3,'pior',.6);
 const sun=ez((u-uS+.12)/.1),no=ez((u-uC+.08)/.04)*(1-ez((u-uS+.12)/.04)),wave=u>uC-.06&&u<uS-.12;
 put('CIB',0,0,-3,G({sc:4.6,m:MD(u,[[0,'worry'],[uC-.05,'cool'],[uS-.1,'happy']]),aR:wave?-70+40*sn(t*9):lp(-25,-125,sun),aL:lp(25,125,sun),tilt:3*sn(t)+(wave?-6*sn(t*1.6):0),look:[0,sun>.05?-8:0],brow:sun>.05?3:2}));
 cam([k0(0,.02,0,0,0),k0(uC,.08,0,0,0),k0(uS-.1,.1,0,0,-.5),k0(uS+.08,.11,-24,30,.6),k0(1,.12,-30,40,.6)]);
 const f=Math.max(0,ez((u-uS+.1)/Math.max(.2,1-uS)));
 const sunp=[905,400],ch=zp(...hand('CIB',1,-125));let ui='';
 if(u>uS-.14){const a=ez((u-uS+.14)/.05);ui+=`<g opacity="${a}"><g ${S}><rect x="190" y="300" width="700" height="46" rx="23" fill="#2a1a40"/><rect x="196" y="306" width="${(688*f).toFixed(1)}" height="34" rx="17" fill="#ffd23f" stroke="none"/></g>`+TXT('ENERGIA SOLAR',540,270,64,'#ffd23f')+'</g>'}
 if(u>=uC-.07&&u<uS-.06){const a=pop(t,(uC-.07)*d);ui+=TXT('🍔',200,520,110*a,'#fff')+TXT('✖',200,545,120*a,'#ff3b3b',0,1+.06*sn(t*8))}
 if(u>uS-.14){const a=ez((u-uS+.14)/.06);ui+=TXT('☀️',sunp[0],sunp[1],150*a,'#fff',0,1+.06*sn(t*3));
  [0,1,2].forEach(i=>{const ox=(i-1)*60;ui+=`<line x1="${sunp[0]-30}" y1="${sunp[1]+50}" x2="${ch[0]+ox}" y2="${ch[1]}" stroke="#ffe27a" stroke-width="10" stroke-linecap="round" stroke-dasharray="26 46" stroke-dashoffset="${(-t*420).toFixed(0)}" opacity="${(.8*a).toFixed(2)}"/>`});
  for(let i=0;i<6;i++){const q=(t*.6+i/6)%1;ui+=TXT('✨',lp(sunp[0]-30,ch[0],q),lp(sunp[1]+50,ch[1],q),54,'#fff')}
  FX.gl=[[sunp[0],sunp[1],520,'255,215,120',.55*a]];FX.tint=[255,200,80,.07*a]}
 FX.ui=ui
},'flash');
shot('twn',4,5,(t,u)=>{
 const d=DD(),uA=UW(4,'alguém',.4),uH=UW(4,'braço',.4),uR=UW(4,'regenerar',.3);
 const hit=u>=uH,heal=u>=uR,hl=ez((u-uR)/.12),aR=!hit?-22+8*sn(t*2)+10*VO(GT)*sn(t*4.1):!heal?38:lp(38,-45,hl);
 put('CIB',0,0,-3,G({sc:5,m:MD(u,[[0,'cool'],[uH,'scared'],[uR,'awe'],[uR+.16,'happy']]),aR,aL:hit?20:22-8*sn(t*2.2)-10*VO(GT)*sn(t*4.3),brow:hit&&!heal?8:0,sx:heal&&u<uR+.14?1+.04*sn(u*60):1,rot:hit&&!heal?-4*Math.max(0,1-(u-uH)/.1):undefined}));
 const sp=CHS.CIB.sp,HP=hand('CIB',1,38),sw=(HP[0]>0?HP:[800,700]);
 const sa=ez((u-uA+.06)/Math.max(.04,uH-.03-uA+.06)),sb=ez((u-uH-.02)/.08);
 const sx=lp(1250,sw[0]+110,sa)+sb*120,sy=sw[1]+80-sb*60*sn(sb*3.14)+(u>uH+.1?10:0);
 if(u>uA-.08)put('S1',0,0,0,{px:[sx,sy],ku:sp[2]*.2,m:hit?(u>uH+.12?'shock':'angry'):'angry',aR:hit&&u<uH+.06?-160:-20,aL:-20,lg:u<uH?26*sn(t*10):0,nodrift:1});
 cam([k0(0,.04,0,0,0),k0(uA,.1,-30,0,0),kf(uH-.03,.2,[sw[0]-90,sw[1]-150],880,0,'c'),kf(uR-.02,.2,[sw[0]-90,sw[1]-150],880,0),k0(uR+.12,.1,0,0,0),k0(1,.12,0,10,0)]);
 const h=zp(sw[0],sw[1]);let ui='';
 if(hit&&u<uH+.1){const a=cl((u-uH)/.1);ui+=RAYS(t,uH*d,h[0],h[1],.35,14,'#ffe27a')+`<path d="M${h[0]-150} ${h[1]-110} Q${h[0]} ${h[1]+20} ${h[0]+150} ${h[1]-110}" fill="none" stroke="${INK}" stroke-width="26" stroke-linecap="round" opacity="${1-a}"/><path d="M${h[0]-150} ${h[1]-110} Q${h[0]} ${h[1]+20} ${h[0]+150} ${h[1]-110}" fill="none" stroke="#fff" stroke-width="12" stroke-linecap="round" opacity="${1-a}"/>`+TXT('💥',h[0]+30,h[1],140,'#fff',0,1.2)+TXT('AI!',540,330,120,'#ff3b3b',-5,pop(t,uH*d))}
 if(heal&&u<uR+.3){const a=1-cl((u-uR)/.3);ui+=STEAM(t,h[0],h[1],a,7)+[0,1,2,3,4].map(i=>TXT('✨',h[0]+60*cs(t*5+i*1.3),h[1]+50*sn(t*5+i*1.3)-20-(i%3)*20,70,'#fff')).join('')+(u<uR+.2?TXT('REGENERA!',540,330,100,'#7dff6b',-3,pop(t,uR*d)):'');
  FX.gl=[[h[0],h[1],380,'120,255,140',.55*a]];FX.tint=[80,255,120,.05*a]}
 FX.ui=ui
},'wr');
shot('twn',5,6,(t,u)=>{
 const d=DD(),uT=UW(5,'ponto',.0)-.03,uN=UW(5,'nuca',.3),q=ez((u-uT)/.07),back=u>uT+.035;
 put('CIB',0,0,-3,G({sc:5,m:back?'blank':'worry',sx:Math.max(.08,ab(1-2*q)),back:1,extra:back?BACKX(t):'',aR:-20,aL:20,brow:back?0:5}));
 const sp=CHS.CIB.sp,nx=sp[0],ny=sp[1]-178*sp[2],k=1.297,beat=Math.max(0,sn((t-uT*d)*5.2))**3;
 cam([k0(0,.04,0,0,.6),k0(uT,.1,0,0,0),k0(uN-.1,.14,0,0,0),k0(uN,.28,-(nx-540)*k,-20-(ny-1000)*k,0),k0(1,.28,-(nx-540)*k,-20-(ny-1000)*k,0)]);
 FX.punch=u>uT+.05?.012*beat:0;FX.tint=u>uT+.05?[255,20,40,.07*beat]:null;FX.shake=u>uT+.05?2*beat:0;
 FX.ui=u>uT+.04?TXT('PONTO FRACO',540,250,104,'#ff3b3b',-3,pop(t,(uT+.04)*d)*(1+.04*sn(t*6))):''
},'zoom');
shot('twn',6,7,(t,u)=>{
 const d=DD();
 put('CIB',0,0,-3,G({sc:5,back:1,extra:BACKX(t),m:'blank',aR:-20+(u>.82?18*sn(t*30):0),aL:20-(u>.82?18*sn(t*28):0),tilt:u>.82?6*sn(t*26):0}));
 const sp=CHS.CIB.sp,nx=sp[0],ny=sp[1]-178*sp[2],k=1.297,P=[-(nx-540)*k,-20-(ny-1000)*k];
 cam([k0(0,.28,P[0],P[1],0),k0(.3,.13,0,0,.8),k0(.74,.15,0,0,-.5),k0(.82,.34,P[0],P[1],0),k0(1,.36,P[0],P[1],0)]);
 const B=zp(sp[0],sp[1]-130*sp[2]),ropes=[];
 ['S1','S2','S3'].forEach((id,i)=>{const s=cl(u*1.25-i*.14),e=ez(s),x=lp([-3.5,3.5,-1.5][i],[-.8,.9,0][i],e),y=lp(0,3.7,e)+1.4*sn(s*3.14);
  put(id,x,y,[-1.5,-1.5,-.5][i],{m:'angry',aR:-150,aL:-20,rot:-14*(1-e)*[1,-1,1][i]});
  const A=zp(...hand(id,1,-150)),ext=ez(cl((u-i*.1-.04)/.2));
  const ex=lp(A[0],B[0],ext),ey=lp(A[1],B[1],ext);
  ropes.push(`<line x1="${A[0]}" y1="${A[1]}" x2="${ex}" y2="${ey}" stroke="${INK}" stroke-width="10" stroke-linecap="round"/><line x1="${A[0]}" y1="${A[1]}" x2="${ex}" y2="${ey}" stroke="#e8e8f0" stroke-width="4" stroke-linecap="round"/>`+STEAM(t+i,A[0]-10,A[1]+10,.6*(e<1?1:0),3)); });
 const hitT=.82*d;FX.shake=14*sh1(t,[hitT],6);FX.punch=.03*sh1(t,[hitT],8);
 FX.ui=ropes.join('')+(u>.82?RAYS(t,hitT,B[0],B[1],.4,16,'#ffe27a')+BURST(t,hitT,B[0],B[1],{n:18,sp:640,r:12,col:'#ffd23f',life:.7})+TXT('💥',B[0],B[1],150,'#fff',0,1+.2*sn(t*30)):'');
 FX.gl=u>.82?[[B[0],B[1],520,'255,225,140',.8*sh1(t,[hitT],7)]]:null
},null);
shot('twn',7,8,(t,u)=>{
 const d=DD(),xA=lp(5,0,ez(u*2.2));
 put('CIB',-3.7,0,-9,{sc:4.5,m:'scared',tilt:-8,look:[7,0],aR:-30+6*sn(t*9),aL:30-6*sn(t*8),brow:7});
 put('AB',xA,0,-2,G({sc:5,sx:.85,m:'grin',tilt:25*sn(t*3.1),look:[8*sn(t*5),5*sn(t*4)],aR:-70+40*sn(t*7),aL:70-40*sn(t*6),lg:u<.4?22*sn(t*8):2,brow:6*sn(t*9)}));
 cam([k0(0,.0,0,0,-1.5),k0(.5,.12,0,10,1),k0(1,.2,0,20,.4)]);
 FX.shake=u<.4?5*Math.max(0,1-ab(sn(t*8))/.15):0;FX.tint=[110,255,120,.05];
 FX.ui=TXT('???',540,300,170,'#ffd23f',-6,pop(t,.25*d)*(1+.06*sn(t*8)))
},'wr');
shot('twn',8,9,(t,u)=>{
 const d=DD(),uR=UW(8,'correr',.4),uS=UW(8,'saltar',.4),uI=UW(8,'imprevisíveis',.3);
 let x=3,y=0,rot=0,sy=1,pz={m:'grin',lg:2,aR:-70+40*sn(t*7),aL:70-40*sn(t*6),tilt:25*sn(t*3.1)},ui='';
 const twitch=u<uR-.06?8*(Math.floor(t*2.6)%2?1:-1):0;
 if(u<uR-.05){x=lp(2.4,1.3,ez(u/(uR-.05)))+.05*sn(t*7);pz={m:'grin',lg:16*sn(t*7),aR:-70+40*sn(t*7),aL:70-40*sn(t*6),rot:twitch*.6,tilt:twitch*3,bobv:-4*ab(sn(t*7))}}
 else if(u<uS-.05){const w=ez((u-uR+.05)/.14);x=lp(1.3,-2.4,w);pz={m:'grin',lg:30*sn(t*14),aR:-120*sn(t*12),aL:120*sn(t*12),rot:-10*(1-ab(2*w-1)),tilt:12,bobv:-9*ab(sn(t*14))};if(w<1)ui+=SPEED(t,.55)}
 else if(u<uS+.16){const w=cl((u-uS+.05)/.21);x=lp(-2.4,2.3,ez(w));y=7*sn(w*3.14);rot=-360*ez(w);sy=w<.08?.78:(w>.92?.84:1.08);pz={m:'awe',lg:0,aR:-150,aL:150,tilt:0,bobv:0};if(w<.9)ui+=SPEED(t,.4)}
 else {const T=[[2.3,0],[-1.2,0],[1.6,0],[-2.6,0],[.4,0]];const w=cl((u-uS-.16)/(1-uS-.16)),n=T.length,k=Math.min(n-1,Math.floor(w*n)),f=ez(w*n-k);const a=T[k],b=T[Math.min(n-1,k+1)];x=lp(a[0],b[0],f);rot=k==1?-360*f:0;pz={m:'grin',lg:26*sn(t*13),aR:-110*sn(t*10),aL:110*sn(t*9),tilt:20*sn(t*6),bobv:-6*ab(sn(t*13))};if(w>.9)pz={m:'grin',lg:0,aR:-20,aL:20,tilt:22,look:[0,0]}}
 put('AB',x,y,-3.5,G({sc:5,sx:.85,sy,rot,...pz}));
 const ax=CHS.AB.sp,cz=CHS.CIB&&0;
 put('CIB',-3.7,0,-9,{sc:4.5,m:u<uR-.05?'scared':(u<uS+.16?'shock':'worry'),tilt:-8,look:[clamp((x+3.7)*2.2,-8,8),0],aR:-30+12*sn(t*13),aL:30-12*sn(t*12),brow:7});
 const fp=scr(x,0,-3.5,5,-200);
 cam([k0(0,.04,0,0,0),k0(uR-.04,.1,0,0,0),k0(uR+.1,.16,clamp((540-ax[0])*.45,-80,80),20,-1),k0(uS-.04,.1,0,0,0),k0(uS+.06,.2,clamp((540-ax[0])*.4,-80,80),60,1.4),k0(uS+.18,.1,0,0,0),k0(uI,.12,0,0,0),k0(1,.18,clamp((540-ax[0])*.4,-80,80),30,-1)]);
 FX.shake=Math.max(0,9*sh1(t,[(uS-.05+.21*.92)*d,(uS-.05)*d],7));
 if(u>uS-.05&&u<uS+.17){const z=zp(ax[0],ax[1]);ui+=RING(t,(uS-.05+.21*.93)*d,z[0],z[1],430,.5,'#fff')}
 FX.ui=ui
},'wl');
shot('twn2',9,10,(t,u)=>{
 const d=DD(),up=ez((u-.45)/.15);
 put('CIB',0,0,-3,G({sc:5.2,m:MD(u,[[0,'cool'],[.45,'happy']]),aR:lp(-25+6*sn(t),-140,up),aL:lp(25-6*sn(t*1.1),140,up),tilt:3*sn(t*.7),look:[6,-3],sy:1+.02*up}));
 cam([k0(0,.0,0,0,1),k0(.5,.1,0,30,0),k0(1,.22,0,90,-.8)]);
 const g=Math.max(0,ez(u*2));FX.gl=[[540,540,760,'255,200,120',.4+.2*sn(t*1.3)],[540,300,420,'255,240,200',.35*g]];
 let sh='';for(let i=0;i<7;i++){const a=(i-3)*.17+.05*sn(t*.6+i);sh+=`<polygon points="540,-80 ${(540+cs(1.57+a)*1500).toFixed(0)},${(sn(1.57+a)*1500).toFixed(0)} ${(540+cs(1.57+a+.07)*1500).toFixed(0)},${(sn(1.57+a+.07)*1500).toFixed(0)}" fill="rgba(255,225,160,${(.07+.04*sn(t+i)).toFixed(3)})"/>`}
 const h=zp(...scr(0,0,-3,5.2,-232).slice(0,2));let ui=sh;
 if(up>.1)for(let i=0;i<5;i++){const q=(t*.7+i/5)%1;ui+=TXT('✨',h[0]+(i-2)*130+30*sn(t+i),h[1]-120-q*140,50+30*rnd(i,3),'#fff')}
 FX.ui=ui
},'flashO');
shot('twn2',10,11,(t,u)=>{
 const d=DD(),uC=UW(10,'controle',.4),r=u>uC-.1,q=u>.18;
 const stm=r?16*ab(sn(t*7)):0,ctrl=u>=uC-.04;
 put('CIB',0,0,-3,G({sc:4.4,m:r?'scared':(q?'shock':'happy'),aR:r?-140*sn(t*8):(q?-100*sn(t*6.5)*ez((u-.18)/.1):-25),aL:r?140*sn(t*7.4):(q?100*sn(t*6)*ez((u-.18)/.1):25),rot:r?7*sn(t*5):(q?4*sn(t*4)*ez((u-.18)/.1):undefined),tilt:r?10*sn(t*9):0,brow:q?8:0,lg:r?22*sn(t*11):0,bobv:r?-stm:undefined}));
 const sp=CHS.CIB.sp;
 cam([k0(0,.04,0,0,0),k0(.18,.06,0,0,0),k0(uC-.1,.1,0,10,-1.5),k0(uC,.14,0,20,2),k0(1,.18,0,30,-1.5)]);
 FX.shake=r?3+10*sh1(t,[uC*d],5):0;
 const z=zp(sp[0],sp[1]);let ui='';
 if(r){const ft=Math.floor(t*3.6)/3.6;ui+=RING(t,ft,z[0],z[1],360,.45,'#fff')}
 if(ctrl){const p=pop(t,(uC-.04)*d);ui+=TXT('SEM CONTROLE!',546,266,110,'#00e5ff',-4,p)+TXT('SEM CONTROLE!',534,274,110,'#ff2d6f',-4,p)+TXT('SEM CONTROLE!',540,270,110,'#fff',-4,p)+RAYS(t,(uC-.04)*d,540,270,.4,14,'#ffd23f')}
 FX.tint=r?[255,30,50,.05+.04*ab(sn(t*6))]:null;FX.ui=ui
},null);

SH.forEach((s,i)=>{if(i<SH.length-1)s.t1=SH[i+1].t0});SH[0].t0=0;SH[SH.length-1].t1=TOTAL+1;
const load=(im,src)=>new Promise(r=>{im.onload=r;im.src=src});
window.F=async gt=>{GT=gt;const sh=SH.find(s=>gt>=s.t0&&gt<s.t1)||SH[SH.length-1];
 if(sh!=CSH){sh.dip=CSH&&CSH.plate!=sh.plate;CSH=sh;sh.pl=sh.plate?getPl(sh.plate):{VP:getPl('liv').VP,tf:1,cam:{}};if(sh.plate){await Promise.all([load($('iA'),`plates/${sh.plate}_A.png`),load($('iB'),`plates/${sh.plate}_B.png`)]);$('LA').style.display=$('LB').style.display='';$('LA').style.background='none'}else{$('LA').style.display='';$('iA').removeAttribute('src');$('LB').style.display='none';$('LA').style.background='radial-gradient(circle at 50% 47%,#ffb85a 0,#7a3a6a 40%,#140a22 78%)';$('iA').style.display='none'}if(sh.plate)$('iA').style.display=''}
 const t=gt-sh.t0,u=cl(t/(sh.t1-sh.t0));CU=u;FX={};FR=[];SHD=[];$('tvbg').innerHTML='';$('tvr').setAttribute('width',0);for(const k in CHS)CHS[k].g.style.display='none';sh.f(t,u);FR.sort((a,b)=>b.z-a.z).forEach(c=>(c.k=='R'?cwR:cw).appendChild(c.g));$('sg').innerHTML=SHD.map(([x,y,k])=>`<ellipse cx="${x}" cy="${y+3*k}" rx="${72*k}" ry="${14*k}" fill="rgba(0,0,0,.45)"/>`).join('');$('SV').style.filter=FX.nof?'none':'drop-shadow(-4px 0 2px rgba(255,170,80,.28)) drop-shadow(4px 0 2px rgba(120,150,255,.25))';
 const eu=ez(u),zb=FX.cz!=null?FX.cz:(FX.z?lp(FX.z[0],FX.z[1],eu):0),pn=FX.cpn||(FX.pan?[lp(FX.pan[0][0],FX.pan[1][0],eu),lp(FX.pan[0][1],FX.pan[1][1],eu)]:[0,0]),Tn=trans(gt,sh),sk=FX.shake||0;
 let z0=(1+zb+.02*emph(gt)+(FX.punch||0))*Tn.s-1;
 const dx=sk*sn(gt*61)+pn[0]+Tn.dx+5*sn(gt*.31)+3*sn(gt*.77),dy=sk*sn(gt*53+1)+pn[1]+Tn.dy+4*sn(gt*.27+2),ox=`${dx}px,${dy}px`,rl=(FX.roll||0)+Tn.r+.3*sn(gt*.5);
 const bl=Tn.bx>.4||Tn.by>.4?'url(#mbx)':'';$('mbg').setAttribute('stdDeviation',`${Tn.bx.toFixed(1)} ${Tn.by.toFixed(1)}`);
 $('LA').style.transform=`translate(${ox}) scale(${1+z0}) rotate(${rl}deg)`;$('SV').style.transform=`translate(${ox}) scale(${1+z0*1.06}) rotate(${rl}deg)`;$('LB').style.transform=`translate(${ox}) scale(${1+z0*1.16}) rotate(${rl}deg)`;
 $('LA').style.filter=$('LB').style.filter=bl||'none';$('SV').style.filter=((FX.nof?'':'drop-shadow(-4px 0 2px rgba(255,170,80,.28)) drop-shadow(4px 0 2px rgba(120,150,255,.25))')+' '+bl).trim()||'none';
 const c=oc;c.clearRect(0,0,W,H);c.globalCompositeOperation='lighter';
 if(sh.plate){const P=sh.pl,g=GLW[sh.plate]||[];g.forEach(([x,y,zz,r,col,a,fl])=>{const q=pj(P.VP,x,y,zz),R=r*(H/2)/(P.tf*q[2])*(1+z0),X=540+(q[0]-540)*(1+z0)+dx,Y=1000+(q[1]-1000)*(1+z0)+dy,aa=a*(fl?.8+.25*sn(gt*13)*sn(gt*4):1),gr=c.createRadialGradient(X,Y,0,X,Y,R);gr.addColorStop(0,`rgba(${col},${aa})`);gr.addColorStop(1,`rgba(${col},0)`);c.fillStyle=gr;c.fillRect(X-R,Y-R,2*R,2*R)});
  if(EXT[sh.plate]||FX.stars){STARS.forEach(([x,y,r],i)=>{c.fillStyle=`rgba(255,245,220,${.25+.5*ab(sn(gt*1.5+i))})`;c.beginPath();c.arc(x,y,r,0,6.3);c.fill()})}else if(!NOD[sh.plate]){for(let i=0;i<50;i++){const hx=a=>Math.abs(sn(i*a)*43758.5453)%1,q=[hx(12.9)*W,(.1+.8*hx(78.2))*H-((gt*14*(1+i%3))%300)],r=2+3*hx(5.5);c.fillStyle=`rgba(255,220,160,${.12+.2*ab(sn(gt*1.4+i))})`;c.beginPath();c.arc(q[0],(q[1]+H)%H,r,0,6.3);c.fill()}}}
 if(sh.plate&&BEAMS[sh.plate]){const P=sh.pl,q=BEAMS[sh.plate].map(([x,y,z])=>{const r=pj(P.VP,x,y,z);return[540+(r[0]-540)*(1+z0)+dx,1000+(r[1]-1000)*(1+z0)+dy]}),gr=c.createLinearGradient(q[0][0],q[0][1],q[2][0],q[2][1]);gr.addColorStop(0,'rgba(190,210,255,.16)');gr.addColorStop(1,'rgba(190,210,255,0)');c.fillStyle=gr;c.beginPath();q.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1]));c.fill()}
 (FX.gl||[]).forEach(([x,y,r,col,al])=>{if(al>0){const q=c.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,`rgba(${col},${al})`);q.addColorStop(1,`rgba(${col},0)`);c.fillStyle=q;c.fillRect(x-r,y-r,2*r,2*r)}});c.globalCompositeOperation='source-over';if(FX.tint){c.fillStyle=`rgba(${FX.tint[0]},${FX.tint[1]},${FX.tint[2]},${FX.tint[3]})`;c.fillRect(0,0,W,H)}
 let gr=c.createLinearGradient(0,0,0,H);gr.addColorStop(0,'rgba(90,60,255,.16)');gr.addColorStop(1,'rgba(255,90,40,.12)');c.fillStyle=gr;c.fillRect(0,0,W,H);gr=c.createRadialGradient(W/2,H*.5,H*.25,W/2,H*.5,H*.68);gr.addColorStop(0,'rgba(10,0,20,0)');gr.addColorStop(1,'rgba(10,0,25,.55)');c.fillStyle=gr;c.fillRect(0,0,W,H);
 if(Tn.fl>0){c.fillStyle=`rgba(${Tn.col},${Tn.fl})`;c.fillRect(0,0,W,H)}const fd=Math.max(.55*cl(1-gt/.2),cl((gt-(TOTAL-.7))/.7));if(fd>0){c.fillStyle=`rgba(0,0,0,${fd})`;c.fillRect(0,0,W,H)}
 $('UI').innerHTML=FX.ui||'';$('UI').style.opacity=1-fd};

window.getSFX=()=>{const L=[],a=(t,k,v=1)=>L.push([+t.toFixed(3),k,v]),T=(i,u)=>SH[i].t0+u*(SH[i].t1-SH[i].t0);
 a(.06,'whoosh',.8);
 SH.forEach((s,i)=>{if(i&&s.tin)a(s.t0-.15,s.tin=='zoom'?'zoom':s.tin.startsWith('flash')?'flash':'whoosh',.9)});
 a(T(0,.76),'crack',1);a(T(0,.76)+.08,'pop',.9);
 {const uE=UW(1,'enorme',.6),uD=UW(1,'desajeitados',.3),uT=UW(1,'tropeçando',.25);
  for(let t=T(1,.0)+.2;t<T(1,uE-.03);t+=.314)a(t,'step',.8);
  a(T(1,uE-.02),'thud',1.3);
  for(let t=T(1,uD);t<T(1,uT);t+=.35)a(t,'step',.5);
  a(T(1,uT),'fall',1.2)}
 {const uI=UW(2,'inteligência',.4),uO=UW(2,'obsessão',.5);
  a(T(2,uI-.06),'zap',.8);a(T(2,uI),'zap',.7);a(T(2,uI+.03),'zap',.6);a(T(2,uI+.07),'fizz',.9);a(T(2,uO-.03),'pop',.9)}
 {const uC=UW(3,'comer',.5),uS=UW(3,'sol',.4);
  a(T(3,uC-.07),'pop',1);a(T(3,uC-.07)+.12,'buzz',.7);a(T(3,uS-.14),'chime',1.1)}
 {const uA=UW(4,'alguém',.4),uH=UW(4,'braço',.4),uR=UW(4,'regenerar',.3);
  a(T(4,uH)-.14,'swish',.9);a(T(4,uH),'crack',1);a(T(4,uH)+.1,'pop',.8);a(T(4,uR),'chime',1)}
 {const uT=UW(5,'ponto',.0)-.03,d=SH[5].t1-SH[5].t0;a(T(5,uT),'swish',.9);a(T(5,uT+.04),'pop',1);
  for(let k=0;;k++){const tt=T(5,uT)+.05*d*0+(.302+1.208*k);if(tt>SH[5].t1-.1)break;if(tt>T(5,uT+.05))a(tt,'beat',1)}}
 {for(let i=0;i<3;i++)a(T(6,i*.1+.06),'swish',.8);a(T(6,.82),'crack',1.3);a(T(6,.82)+.04,'thud',1)}
 {a(T(7,.25),'pop',1);a(T(7,.05),'thud',.9);a(T(7,.32),'thud',.9)}
 {const uR=UW(8,'correr',.4),uS=UW(8,'saltar',.4);a(T(8,uR-.05),'whoosh',1);a(T(8,uS-.05),'boing',1);a(T(8,uS-.05+.21*.93),'thud',1.2);
  const q=(1-uS-.16)/5;for(let k=1;k<4;k++)a(T(8,uS+.16+k*q),'swish',.9)}
 {a(T(9,.04),'chime',.7);a(T(9,.5),'chime',.9)}
 {const uC=UW(10,'controle',.4);a(T(10,uC-.04),'crack',1.2);a(T(10,uC-.04)+.05,'glitch',.9);
  for(let t=T(10,uC-.1);t<TOTAL-.4;t+=1/3.6)a(t,'thud',.7)}
 L.sort((x,y)=>x[0]-y[0]);return L};
