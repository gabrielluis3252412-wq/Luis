import json,re,os
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page();pg.goto('file:///home/claude/titan/story.html');segs=pg.evaluate('SPEECH');tot=pg.evaluate('TOTAL');b.close()
COL=['3FD2FF','8F5DFF','FFD94C','6BFF7D']
def toks(t):
    out=[];hl=False;gid=-1
    for part in re.split(r'(\*)',t):
        if part=='*':hl=not hl;gid+=1 if hl else 0;continue
        for w in part.split():out.append((w,hl,gid))
    return out
def ts(x):
    h=int(x//3600);m=int(x%3600//60);s=x%60;return f"{h}:{m:02d}:{s:05.2f}"
ev=[];ci=0
for text,a,bb,ints in segs:
    w=toks(text);ch=[];cur=[]
    for k,(x,h,g) in enumerate(w):
        cur.append((x,h,g))
        if (len(cur)>=6) or (len(cur)>=3 and re.search(r'[.,!?:]$',x)):ch.append(cur);cur=[]
    if cur:
        if ch and len(cur)<2:ch[-1]+=cur
        else:ch.append(cur)
    L=[sum(len(x)+1 for x,_,_ in c) for c in ch];tot_l=sum(L)
    # fronteiras proporcionais, ajustadas para as pausas reais do audio
    cum=0;B=[a]
    for l in L:cum+=l;B.append(a+(bb-a)*cum/tot_l)
    gaps=[None]*len(ch)
    used=set()
    for k in range(len(ch)-1):
        if not re.search(r'[.,!?:…]$',ch[k][-1][0]):continue
        best=None
        for j,(s0,s1) in enumerate(ints):
            if j in used:continue
            d=abs((s0+s1)/2-B[k+1])
            if d<1.2 and (best is None or d<best[0]):best=(d,j)
        if best:used.add(best[1]);gaps[k]=ints[best[1]]
    t=a
    for k,c in enumerate(ch):
        end=gaps[k][0] if gaps[k] else (B[k+1] if k<len(ch)-1 else bb)
        if end<=t+.15:end=t+.15
        sx=''
        for x,h,g in c:
            if h:sx+='{\\c&H%s&}%s{\\c&HFFFFFF&} '%(COL[(g+ci)%4],x)
            else:sx+=x+' '
        ev.append((t,end,sx.strip()))
        t=gaps[k][1] if gaps[k] else end
    ci+=1
hdr='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 0

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Cap,Poppins,82,&H00FFFFFF,&H00FFFFFF,&H00241018,&H00000000,1,0,0,0,100,100,0,0,1,9,2,2,70,70,330,1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
'''
open('/mnt/user-data/outputs/cibito-titan.ass','w',encoding='utf-8').write(hdr+''.join(f"Dialogue: 0,{ts(a)},{ts(b)},Cap,,0,0,0,,{t}\n" for a,b,t in ev))
print(len(ev),'legendas; total',round(tot,1))
