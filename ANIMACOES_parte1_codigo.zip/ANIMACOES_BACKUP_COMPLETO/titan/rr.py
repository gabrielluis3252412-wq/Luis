import os,sys,math,subprocess,json
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
FPS=24
if sys.argv[1]=='plan':
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b=p.chromium.launch();pg=b.new_page(viewport={'width':1080,'height':1920});pg.goto('file:///home/claude/titan/story.html')
        sh=pg.evaluate('SH.map(s=>[s.t0,s.t1])');b.close()
    fr=[]
    for i in (0,1,3,5,7,8):
        a,b2=sh[i];fr+=range(max(0,int(a*FPS)-1),min(2136,int(b2*FPS)+2))
    fr=sorted(set(fr));json.dump(fr,open('todo.json','w'));print(len(fr),fr[0],fr[-1])
else:
    from playwright.sync_api import sync_playwright
    fr=json.load(open('todo.json'));a,b=int(sys.argv[2]),int(sys.argv[3])
    with sync_playwright() as p:
        br=p.chromium.launch();pg=br.new_page(viewport={'width':1080,'height':1920});pg.goto('file:///home/claude/titan/story.html')
        for i in fr[a:b]:
            pg.evaluate(f"F({i/FPS})");pg.screenshot(path=f'frames5/{i:05d}.jpg',type='jpeg',quality=92)
        br.close()
    print('ok',a,b,flush=True)
