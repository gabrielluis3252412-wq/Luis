import os,sys,shutil,time,math
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
FPS=24;shutil.rmtree('frames5',ignore_errors=True);os.makedirs('frames5')
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={'width':1080,'height':1920})
    pg.on('pageerror',lambda e:print('ERR',e))
    pg.goto('file:///home/claude/titan/story.html')
    TOTAL=pg.evaluate('TOTAL');N=int(math.ceil(TOTAL*FPS));print('frames',N,flush=True)
    t0=time.time()
    for i in range(N):
        pg.evaluate(f"F({i/FPS})");pg.screenshot(path=f'frames5/{i:05d}.jpg',type='jpeg',quality=92)
        if i%100==0: print(i,round(time.time()-t0,1),flush=True)
    b.close()
print('done',round(time.time()-t0,1))
