import os,sys,math,time
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
FPS=24;a=int(sys.argv[1]);b=int(sys.argv[2])
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':1080,'height':1920})
    pg.on('pageerror',lambda e:print('ERR',e))
    pg.goto('file:///home/claude/titan/story.html')
    N=int(math.ceil(pg.evaluate('TOTAL')*FPS));b=min(b,N)
    for i in range(a,b):
        pg.evaluate(f"F({i/FPS})");pg.screenshot(path=f'frames5/{i:05d}.jpg',type='jpeg',quality=92)
    br.close()
print('ok',a,b,N,flush=True)
