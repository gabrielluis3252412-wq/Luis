shot('bed',0,1,(t,u)=>{
 const d=DD(),sl=u<.26,yw=ez((u-.26)/.07)*(1-ez((u-.46)/.07)),st=ez((u-.40)/.12)*(1-ez((u-.70)/.05)),lk=u>=.76,tS=.76*d;
 const f=scr(0,.85,-2.6,1,-142);
 put('CIB',0,.85,-2.6,{sit:1,m:sl?'sleepy':lk?'shock':yw>.02?'talka':'happy',mry:yw>.02?3+yw*22:undefined,mrx:yw>.02?16:undefined,aR:st*-150,aL:st*150,brow:lk?8:0,tilt:sl?9*sn(t*2):-4*yw,look:lk?[0,6]:[0,0],nobob:sl,sy:1+.012*sn(t*2.2)+.045*yw+.03*st,vo:0});
 cam([kf(0,.36,f,880,-1.5),kf(.24,.13,f,1000,0),kf(.3,.13,f,1000,0),kf(.46,.3,f,920,1.2),kf(.5,.3,f,920,1.2),kf(.64,.1,f,1000,0),kf(.72,.1,f,1000,0),kf(.76,.4,f,860,0,'c'),kf(1,.47,f,860,0)]);
 FX.shake=15*sh1(t,[tS],6);FX.gl=lk?[[540,860,760,'255,235,190',.75*sh1(t,[tS],8)]]:null;
 const zf=zp(f[0],f[1]);
 FX.ui=(sl?[0,1,2].map(i=>{const ph=(t*.45+i/3)%1;return`<g opacity="${(Math.min(1,ph*8)*(1-ph)).toFixed(2)}">`+TXT('Z',zf[0]+110+ph*70+i*14,zf[1]-70-ph*300,56+ph*60,'#9ad0ff',8,1)+'</g>'}).join(''):'')+(lk?RAYS(t,tS,540,860,.4,18)+TXT('TITÃ?!',540,300,170,'#ffd23f',-4,pop(t,tS)):'')
},null);
shot('twn',1,2,(t,u)=>{
 const d=DD(),uE=UW(1,'enorme',.6),uD=UW(1,'desajeitados',.3),uT=UW(1,'tropeçando',.25),uU=UW(1,'andando',.15);
 const P1=u<uE-.02,P2=!P1&&u<uD-.03,P3=!P1&&!P2&&u<uT,P4=u>=uT&&u<uU;
 const w=cl(u/(uE-.02)),wb=ez((u-uD+.03)/.05)*(1-ez((u-uT)/.02)),tp=ez((u-uT)/.03),up=ez((u-uU)/.1),fall=tp*(1-up);
 const x0=lp(-2.4,.4,ez(w))+(P3?.12*sn(t*3.1):0);
 let pz={m:'happy',...walk(t,10)};
 if(!P1)pz={m:'cool',aR:-62-10*sn(t*6),aL:62+10*sn(t*6),lg:0,rot:0,bobv:0,sy:1+.05*ez((u-uE+.02)/.03)*(1-ez((u-uE-.04)/.05))};
 if(P3)pz={m:'worry',aR:-20-80*sn(t*8)*wb,aL:20+80*sn(t*7)*wb,lg:28*sn(t*9)*wb,rot:9*sn(t*5)*wb,bobv:-5*ab(sn(t*9))*wb,brow:5};
 if(u>=uT)pz={m:P4?'scared':'blank',rot:-78*fall,aR:-130*fall-20*(1-fall),aL:130*fall+20*(1-fall),lg:0,brow:fall*8};
 put('CIB',x0,0,-3,G({sc:4.8,...pz}));
 const sp=CHS.CIB.sp;
 FX.shake=P1?6*Math.max(0,1-ab(sn(t*10))/.14):0;FX.shake=Math.max(FX.shake,16*sh1(t,[uE*d,uT*d+.05],7));
 cam([k0(0,.22,80,40,-.8),k0(uE-.02,.1,0,0,0),k0(uE+.06,.1,0,0,0),k0(uD-.03,.16,0,30,.8),k0(uT-.01,.2,0,60,-1),k0(uT+.05,.08,0,0,1.5),k0(uU,.08,0,0,0),k0(1,.12,0,20,0)]);
 if(u>uT&&u<uT+.12){const a=cl((u-uT)/.12);sprite(DUST(a),sp[0]+120,sp[1]-6,sp[2]*1.5,40,'C2')}
 run('T1',3.6,-3.8,3,t,u,uE-.05,uE+.28);run('T2',-3.8,3.8,3.6,t,u,uE,uE+.32);
 const z=zp(sp[0],sp[1]);let ui='';
 if(u>=uE-.02&&u<uE+.2)ui+=RING(t,(uE-.02)*d,z[0],z[1],420,.6,'#fff')+BURST(t,(uE-.02)*d,z[0],z[1]-10,{n:12,sp:520,r:14,col:'#f4e4c8',life:.6});
 if(u>=uT&&u<uT+.2)ui+=RING(t,uT*d,z[0]+150,z[1],480,.6,'#fff')+BURST(t,uT*d,z[0]+150,z[1]-10,{n:16,sp:620,r:16,col:'#f4e4c8',life:.7,grav:1});
 if(u>uT+.04&&u<uU){const h=zp(...HEAD(-78));[0,1,2].forEach(i=>{const a=t*5+i*2.1;ui+=TXT('⭐',h[0]+90*cs(a),h[1]-40+34*sn(a),64,'#ffd23f')})}
 FX.ui=ui;FX.tint=null
},'zoom');
shot('twn',2,3,(t,u)=>{
 const d=DD(),uI=UW(2,'inteligência',.4),uO=UW(2,'obsessão',.5),uP=UW(2,'pessoas',.4);
 const H1={a:uO-.04,b:Math.min(1,uO+.2)},H2={a:uO+.02,b:Math.min(1,uO+.24)},H3={a:uO+.08,b:Math.min(1,uO+.26)};
 const hx=(H,x0,x1)=>{const w=(u-H.a)/(H.b-H.a);return w>0&&w<1?lp(x0,x1,w):null};
 const hs=[hx(H1,3.8,-3.8),hx(H2,-3.8,3.8),hx(H3,3.8,-3.8)].filter(v=>v!=null),tx=hs.length?hs.reduce((a,b)=>ab(a)<ab(b)?a:b):0;
 const hung=u>=uO-.03,dumb=u>=uI+.05&&!hung;
 put('CIB',0,0,-3,G({sc:5,m:MD(u,[[0,'smirk'],[uI+.05,'blank'],[uO-.03,'awe']]),tilt:dumb?14*sn(t*1.6):(hung?-5*tx*.4:3*sn(t)),look:hung?[clamp(tx*4,-10,10),0]:(dumb?[9*sn(t*2.2),0]:[0,0]),rot:hung?clamp(tx*1.4,-6,6):1.3*sn(t*.9),
  aR:hung?-70-30*sn(t*5):(dumb?-55+8*sn(t*3):-25),aL:hung?70+30*sn(t*5.3):(dumb?55-8*sn(t*3.3):25),brow:hung?5:0,
  extra:dumb?`<path d="M12-190q${4+2*sn(t*3)} ${14+6*ab(sn(t*2))} 0 ${22+8*ab(sn(t*2))}q-4-10 0-22" fill="#9ad0ff" ${S4}/>`:''}));
 run('T1',3.8,-3.8,2.4,t,u,H1.a,H1.b);run('T2',-3.8,3.8,3.2,t,u,H2.a,H2.b);run('T3',3.8,-3.8,1.6,t,u,H3.a,H3.b);
 const hp=scr(0,0,-3,5,-232),bp=scr(0,0,-3,5,-440);
 cam([k0(0,.0,0,0,1),k0(uI-.05,.1,0,20,0),k0(uI+.12,.16,0,50,-.8),k0(uO-.05,.08,0,20,.5),k0(uO+.1,.1,clamp(-tx*18,-40,40),20,-.5),k0(1,.14,0,30,.6)]);
 const bz=zp(bp[0],bp[1]);let ui='';
 if(u>=uI-.06&&u<uI+.07){const on=u<uI-.0?1:(Math.floor(t*18)%2?1:.15);ui+=`<g opacity="${on}">`+TXT('💡',bz[0],bz[1],150,'#fff',0,1)+'</g>';FX.gl=[[bz[0],bz[1],420,'255,230,120',.5*on]]}
 else if(u>=uI+.07&&u<uI+.2){const a=cl((u-uI-.07)/.13);ui+=`<g opacity="${1-a}">`+TXT('💨',bz[0]+60*a,bz[1]-40-80*a,130,'#fff')+'</g>'}
 if(dumb&&u>uI+.16)ui+=`<g opacity=".9">`+TXT('...',bz[0],bz[1]+30,120,'#fff')+'</g>';
 if(u>=uO-.03&&u<uO+.12){const a=ez((u-uO+.03)/.05);ui+=TXT('👀',bz[0],bz[1]+20,130*a,'#fff',-6,1)}
 FX.ui=ui
},'wl');
shot('twn',3,4,(t,u)=>{
 const d=DD(),uC=UW(3,'comer',.5),uS=UW(3,'sol',.4),uP=UW(3,'pior',.6);
 const sun=ez((u-uS+.12)/.1),no=ez((u-uC+.08)/.04)*(1-ez((u-uS+.12)/.04)),wave=u>uC-.06&&u<uS-.12;
 put('CIB',0,0,-3,G({sc:4.6,m:MD(u,[[0,'worry'],[uC-.05,'cool'],[uS-.1,'happy']]),aR:wave?-70+40*sn(t*9):lp(-25,-125,sun),aL:lp(25,125,sun),tilt:3*sn(t)+(wave?-6*sn(t*1.6):0),look:[0,sun>.05?-8:0],brow:sun>.05?3:2}));
 cam([k0(0,.02,0,0,0),k0(uC,.08,0,0,0),k0(uS-.1,.1,0,0,-.5),k0(uS+.08,.18,-40,60,.8),k0(1,.2,-40,60,.8)]);
 const f=Math.max(0,ez((u-uS+.1)/Math.max(.2,1-uS)));
 const sunp=[880,480],ch=zp(...scr(0,0,-3,4.6,-170).slice(0,2));let ui='';
 if(u>uS-.14){const a=ez((u-uS+.14)/.05);ui+=`<g opacity="${a}"><g ${S}><rect x="190" y="300" width="700" height="46" rx="23" fill="#2a1a40"/><rect x="196" y="306" width="${(688*f).toFixed(1)}" height="34" rx="17" fill="#ffd23f" stroke="none"/></g>`+TXT('ENERGIA SOLAR',540,270,64,'#ffd23f')+'</g>'}
 if(u>=uC-.07&&u<uS-.06){const a=pop(t,(uC-.07)*d);ui+=TXT('🍔',200,520,110*a,'#fff')+TXT('✖',200,545,120*a,'#ff3b3b',0,1+.06*sn(t*8))}
 if(u>uS-.14){const a=ez((u-uS+.14)/.06);ui+=TXT('☀️',sunp[0],sunp[1],150*a,'#fff',0,1+.06*sn(t*3));
  [0,1,2].forEach(i=>{const ox=(i-1)*60;ui+=`<line x1="${sunp[0]-30}" y1="${sunp[1]+50}" x2="${ch[0]+ox}" y2="${ch[1]}" stroke="#ffe27a" stroke-width="10" stroke-linecap="round" stroke-dasharray="26 46" stroke-dashoffset="${(-t*420).toFixed(0)}" opacity="${(.8*a).toFixed(2)}"/>`});
  for(let i=0;i<6;i++){const q=(t*.6+i/6)%1;ui+=TXT('✨',lp(sunp[0]-30,ch[0],q),lp(sunp[1]+50,ch[1],q),54,'#fff')}
  FX.gl=[[sunp[0],sunp[1],520,'255,215,120',.55*a]];FX.tint=[255,200,80,.07*a]}
 FX.ui=ui
},'flash');
shot('twn',4,5,(t,u)=>{
 const d=DD(),uA=UW(4,'alguém',.4),uH=UW(4,'braço',.4),uR=UW(4,'regenerar',.3);
 const hit=u>=uH,heal=u>=uR,hl=ez((u-uR)/.12),aR=!hit?-20+3*sn(t*2):!heal?38:lp(38,-45,hl);
 put('CIB',0,0,-3,G({sc:5,m:MD(u,[[0,'cool'],[uH,'scared'],[uR,'awe'],[uR+.16,'happy']]),aR,aL:20,brow:hit&&!heal?8:0,sx:heal&&u<uR+.14?1+.04*sn(u*60):1,rot:hit&&!heal?-4*Math.max(0,1-(u-uH)/.1):undefined}));
 const sp=CHS.CIB.sp,HP=hand('CIB',1,38),sw=(HP[0]>0?HP:[800,700]);
 const sa=ez((u-uA+.06)/Math.max(.04,uH-.03-uA+.06)),sb=ez((u-uH-.02)/.08);
 const sx=lp(1250,sw[0]+110,sa)+sb*120,sy=sw[1]+80-sb*60*sn(sb*3.14)+(u>uH+.1?10:0);
 if(u>uA-.08)put('S1',0,0,0,{px:[sx,sy],ku:sp[2]*.2,m:hit?(u>uH+.12?'shock':'angry'):'angry',aR:hit&&u<uH+.06?-160:-20,aL:-20,lg:u<uH?26*sn(t*10):0,nodrift:1});
 cam([k0(0,.04,0,0,0),k0(uA,.1,-30,0,0),kf(uH-.03,.3,sw,900,0,'c'),kf(uR-.02,.3,sw,900,0),k0(uR+.12,.1,0,0,0),k0(1,.12,0,10,0)]);
 const h=zp(sw[0],sw[1]);let ui='';
 if(hit&&u<uH+.1){const a=cl((u-uH)/.1);ui+=RAYS(t,uH*d,h[0],h[1],.35,14,'#ffe27a')+`<path d="M${h[0]-150} ${h[1]-110} Q${h[0]} ${h[1]+20} ${h[0]+150} ${h[1]-110}" fill="none" stroke="${INK}" stroke-width="26" stroke-linecap="round" opacity="${1-a}"/><path d="M${h[0]-150} ${h[1]-110} Q${h[0]} ${h[1]+20} ${h[0]+150} ${h[1]-110}" fill="none" stroke="#fff" stroke-width="12" stroke-linecap="round" opacity="${1-a}"/>`+TXT('💥',h[0]+30,h[1],140,'#fff',0,1.2)+TXT('AI!',540,330,120,'#ff3b3b',-5,pop(t,uH*d))}
 if(heal&&u<uR+.3){const a=1-cl((u-uR)/.3);ui+=STEAM(t,h[0],h[1],a,7)+[0,1,2,3,4].map(i=>TXT('✨',h[0]+60*cs(t*5+i*1.3),h[1]+50*sn(t*5+i*1.3)-20-(i%3)*20,70,'#fff')).join('')+(u<uR+.2?TXT('REGENERA!',540,330,100,'#7dff6b',-3,pop(t,uR*d)):'');
  FX.gl=[[h[0],h[1],380,'120,255,140',.55*a]];FX.tint=[80,255,120,.05*a]}
 FX.ui=ui
},'wr');
shot('twn',5,6,(t,u)=>{
 const d=DD(),uT=UW(5,'ponto',.0)-.03,uN=UW(5,'nuca',.3),q=ez((u-uT)/.07),back=u>uT+.035;
 put('CIB',0,0,-3,G({sc:5,m:back?'blank':'worry',sx:Math.max(.08,ab(1-2*q)),back:1,extra:back?BACKX(t):'',aR:-20,aL:20,brow:back?0:5}));
 const sp=CHS.CIB.sp,nx=sp[0],ny=sp[1]-178*sp[2],k=1.297,beat=Math.max(0,sn((t-uT*d)*5.2))**3;
 cam([k0(0,.04,0,0,.6),k0(uT,.1,0,0,0),k0(uN-.1,.14,0,0,0),k0(uN,.28,-(nx-540)*k,-20-(ny-1000)*k,0),k0(1,.28,-(nx-540)*k,-20-(ny-1000)*k,0)]);
 FX.punch=u>uT+.05?.012*beat:0;FX.tint=u>uT+.05?[255,20,40,.07*beat]:null;FX.shake=u>uT+.05?2*beat:0;
 FX.ui=u>uT+.04?TXT('PONTO FRACO',540,250,104,'#ff3b3b',-3,pop(t,(uT+.04)*d)*(1+.04*sn(t*6))):''
},'zoom');
shot('twn',6,7,(t,u)=>{
 const d=DD();
 put('CIB',0,0,-3,G({sc:5,back:1,extra:BACKX(t),m:'blank',aR:-20+(u>.82?18*sn(t*30):0),aL:20-(u>.82?18*sn(t*28):0),tilt:u>.82?6*sn(t*26):0}));
 const sp=CHS.CIB.sp,nx=sp[0],ny=sp[1]-178*sp[2],k=1.297,P=[-(nx-540)*k,-20-(ny-1000)*k];
 cam([k0(0,.28,P[0],P[1],0),k0(.3,.13,0,0,.8),k0(.74,.15,0,0,-.5),k0(.82,.34,P[0],P[1],0),k0(1,.36,P[0],P[1],0)]);
 const nape=pj(CSH.pl.VP,0,4.5,-3),B=zp(nape[0],nape[1]),ropes=[];
 ['S1','S2','S3'].forEach((id,i)=>{const s=cl(u*1.25-i*.14),e=ez(s),x=lp([-3.5,3.5,-1.5][i],[-.8,.9,0][i],e),y=lp(0,4.3,e)+1.6*sn(s*3.14);
  put(id,x,y,[-1.5,-1.5,-.5][i],{m:'angry',aR:-150,aL:-20,rot:-14*(1-e)*[1,-1,1][i]});
  const A=zp(...hand(id,1,-150)),ext=ez(cl((u-i*.1-.04)/.2));
  const ex=lp(A[0],B[0],ext),ey=lp(A[1],B[1],ext);
  ropes.push(`<line x1="${A[0]}" y1="${A[1]}" x2="${ex}" y2="${ey}" stroke="${INK}" stroke-width="10" stroke-linecap="round"/><line x1="${A[0]}" y1="${A[1]}" x2="${ex}" y2="${ey}" stroke="#e8e8f0" stroke-width="4" stroke-linecap="round"/>`+STEAM(t+i,A[0]-10,A[1]+10,.6*(e<1?1:0),3)); });
 const hitT=.82*d;FX.shake=14*sh1(t,[hitT],6);FX.punch=.03*sh1(t,[hitT],8);
 FX.ui=ropes.join('')+(u>.82?RAYS(t,hitT,B[0],B[1],.4,16,'#ffe27a')+BURST(t,hitT,B[0],B[1],{n:18,sp:640,r:12,col:'#ffd23f',life:.7})+TXT('💥',B[0],B[1],150,'#fff',0,1+.2*sn(t*30)):'');
 FX.gl=u>.82?[[B[0],B[1],520,'255,225,140',.8*sh1(t,[hitT],7)]]:null
},null);
shot('twn',7,8,(t,u)=>{
 const d=DD(),xA=lp(5,0,ez(u*2.2));
 put('CIB',-3.7,0,-9,{sc:4.5,m:'scared',tilt:-8,look:[7,0],aR:-30+6*sn(t*9),aL:30-6*sn(t*8),brow:7});
 put('AB',xA,0,-2,G({sc:5,sx:.85,m:'grin',tilt:25*sn(t*3.1),look:[8*sn(t*5),5*sn(t*4)],aR:-70+40*sn(t*7),aL:70-40*sn(t*6),lg:u<.4?22*sn(t*8):2,brow:6*sn(t*9)}));
 cam([k0(0,.0,0,0,-1.5),k0(.5,.12,0,10,1),k0(1,.2,0,20,.4)]);
 FX.shake=u<.4?5*Math.max(0,1-ab(sn(t*8))/.15):0;FX.tint=[110,255,120,.05];
 FX.ui=TXT('???',540,300,170,'#ffd23f',-6,pop(t,.25*d)*(1+.06*sn(t*8)))
},'wr');
shot('twn',8,9,(t,u)=>{
 const d=DD(),uR=UW(8,'correr',.4),uS=UW(8,'saltar',.4),uI=UW(8,'imprevisíveis',.3);
 let x=3,y=0,rot=0,sy=1,pz={m:'grin',lg:2,aR:-70+40*sn(t*7),aL:70-40*sn(t*6),tilt:25*sn(t*3.1)},ui='';
 const twitch=u<uR-.06?8*(Math.floor(t*2.6)%2?1:-1):0;
 if(u<uR-.05){x=3+.1*sn(t*7);pz.rot=twitch*.6;pz.tilt=twitch*3}
 else if(u<uS-.05){const w=ez((u-uR+.05)/.14);x=lp(3,-2.4,w);pz={m:'grin',lg:30*sn(t*14),aR:-120*sn(t*12),aL:120*sn(t*12),rot:-10*(1-ab(2*w-1)),tilt:12,bobv:-9*ab(sn(t*14))};if(w<1)ui+=SPEED(t,.55)}
 else if(u<uS+.16){const w=cl((u-uS+.05)/.21);x=lp(-2.4,2.3,ez(w));y=7*sn(w*3.14);rot=-360*ez(w);sy=w<.08?.78:(w>.92?.84:1.08);pz={m:'awe',lg:0,aR:-150,aL:150,tilt:0,bobv:0};if(w<.9)ui+=SPEED(t,.4)}
 else {const T=[[2.3,0],[-1.2,0],[1.6,0],[-2.6,0],[.4,0]];const w=cl((u-uS-.16)/(1-uS-.16)),n=T.length,k=Math.min(n-1,Math.floor(w*n)),f=ez(w*n-k);const a=T[k],b=T[Math.min(n-1,k+1)];x=lp(a[0],b[0],f);rot=k==1?-360*f:0;pz={m:'grin',lg:26*sn(t*13),aR:-110*sn(t*10),aL:110*sn(t*9),tilt:20*sn(t*6),bobv:-6*ab(sn(t*13))};if(w>.9)pz={m:'grin',lg:0,aR:-20,aL:20,tilt:22,look:[0,0]}}
 put('AB',x,y,-3.5,G({sc:5,sx:.85,sy,rot,...pz}));
 const ax=CHS.AB.sp,cz=CHS.CIB&&0;
 put('CIB',-3.7,0,-9,{sc:4.5,m:u<uR-.05?'scared':(u<uS+.16?'shock':'worry'),tilt:-8,look:[clamp((x+3.7)*2.2,-8,8),0],aR:-30+12*sn(t*13),aL:30-12*sn(t*12),brow:7});
 const fp=scr(x,0,-3.5,5,-200);
 cam([k0(0,.04,0,0,0),k0(uR-.04,.1,0,0,0),k0(uR+.1,.16,clamp((540-ax[0])*.45,-80,80),20,-1),k0(uS-.04,.1,0,0,0),k0(uS+.06,.2,clamp((540-ax[0])*.4,-80,80),60,1.4),k0(uS+.18,.1,0,0,0),k0(uI,.12,0,0,0),k0(1,.18,clamp((540-ax[0])*.4,-80,80),30,-1)]);
 FX.shake=Math.max(0,9*sh1(t,[(uS-.05+.21*.92)*d,(uS-.05)*d],7));
 if(u>uS-.05&&u<uS+.17){const z=zp(ax[0],ax[1]);ui+=RING(t,(uS-.05+.21*.93)*d,z[0],z[1],430,.5,'#fff')}
 FX.ui=ui
},'wl');
shot('twn2',9,10,(t,u)=>{
 const d=DD(),up=ez((u-.45)/.15);
 put('CIB',0,0,-3,G({sc:5.2,m:MD(u,[[0,'cool'],[.45,'happy']]),aR:lp(-25+6*sn(t),-140,up),aL:lp(25-6*sn(t*1.1),140,up),tilt:3*sn(t*.7),look:[6,-3],sy:1+.02*up}));
 cam([k0(0,.0,0,0,1),k0(.5,.1,0,30,0),k0(1,.22,0,90,-.8)]);
 const g=Math.max(0,ez(u*2));FX.gl=[[540,540,760,'255,200,120',.4+.2*sn(t*1.3)],[540,300,420,'255,240,200',.35*g]];
 let sh='';for(let i=0;i<7;i++){const a=(i-3)*.17+.05*sn(t*.6+i);sh+=`<polygon points="540,-80 ${(540+cs(1.57+a)*1500).toFixed(0)},${(sn(1.57+a)*1500).toFixed(0)} ${(540+cs(1.57+a+.07)*1500).toFixed(0)},${(sn(1.57+a+.07)*1500).toFixed(0)}" fill="rgba(255,225,160,${(.07+.04*sn(t+i)).toFixed(3)})"/>`}
 const h=zp(...scr(0,0,-3,5.2,-232).slice(0,2));let ui=sh;
 if(up>.1)for(let i=0;i<5;i++){const q=(t*.7+i/5)%1;ui+=TXT('✨',h[0]+(i-2)*130+30*sn(t+i),h[1]-120-q*140,50+30*rnd(i,3),'#fff')}
 FX.ui=ui
},'flashO');
shot('twn2',10,11,(t,u)=>{
 const d=DD(),uC=UW(10,'controle',.4),r=u>uC-.1,q=u>.18;
 const stm=r?16*ab(sn(t*7)):0,ctrl=u>=uC-.04;
 put('CIB',0,0,-3,G({sc:5,m:r?'scared':(q?'shock':'happy'),aR:r?-140*sn(t*8):(q?-100*sn(t*6.5)*ez((u-.18)/.1):-25),aL:r?140*sn(t*7.4):(q?100*sn(t*6)*ez((u-.18)/.1):25),rot:r?7*sn(t*5):(q?4*sn(t*4)*ez((u-.18)/.1):undefined),tilt:r?10*sn(t*9):0,brow:q?8:0,lg:r?22*sn(t*11):0,bobv:r?-stm:undefined}));
 const sp=CHS.CIB.sp;
 cam([k0(0,.06,0,0,0),k0(.18,.08,0,0,0),k0(uC-.1,.14,0,10,-1.5),k0(uC,.2,0,30,2),k0(1,.26,0,40,-1.5)]);
 FX.shake=r?3+10*sh1(t,[uC*d],5):0;
 const z=zp(sp[0],sp[1]);let ui='';
 if(r){const ft=Math.floor(t*3.6)/3.6;ui+=RING(t,ft,z[0],z[1],360,.45,'#fff')}
 if(ctrl){const p=pop(t,(uC-.04)*d);ui+=TXT('SEM CONTROLE!',546,326,110,'#00e5ff',-4,p)+TXT('SEM CONTROLE!',534,334,110,'#ff2d6f',-4,p)+TXT('SEM CONTROLE!',540,330,110,'#fff',-4,p)+RAYS(t,(uC-.04)*d,540,330,.4,14,'#ffd23f')}
 FX.tint=r?[255,30,50,.05+.04*ab(sn(t*6))]:null;FX.ui=ui
},null);
