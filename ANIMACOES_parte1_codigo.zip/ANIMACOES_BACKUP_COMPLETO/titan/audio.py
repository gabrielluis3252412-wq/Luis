import numpy as np, json, subprocess, wave
SR=44100
rng=np.random.default_rng(7)
def T(d): return np.arange(int(d*SR))/SR
def env(n,a=.005,r=.1,p=3):
    e=np.ones(n); na=max(1,int(a*SR)); e[:na]=np.linspace(0,1,na)
    nr=max(1,int(r*SR)); x=np.linspace(1,0,nr)**p; e[-nr:]*=x if nr<=n else 1; return e
def lp(x,fc):
    # one-pole low-pass with (array) cutoff
    fc=np.broadcast_to(fc,x.shape); a=1-np.exp(-2*np.pi*fc/SR); y=np.zeros_like(x); s=0
    for i in range(len(x)): s+=a[i]*(x[i]-s); y[i]=s
    return y
def noise(n): return rng.standard_normal(n)*.5
def hp(x,fc): return x-lp(x,fc)
def sweep(f0,f1,d,curve=1):
    t=T(d); f=f0+(f1-f0)*(t/d)**curve; return np.sin(2*np.pi*np.cumsum(f)/SR)
def decay(n,k): return np.exp(-np.linspace(0,k,n))
def whoosh(d=.38,hi=3500):
    n=int(d*SR); x=noise(n); fc=300+hi*np.sin(np.linspace(0,np.pi,n))**1.5
    y=lp(x,fc); y*=np.sin(np.linspace(0,np.pi,n))**1.4; return y*1.6
def zoom(d=.4):
    n=int(d*SR); x=noise(n); fc=200+5000*np.linspace(0,1,n)**2
    y=lp(x,fc)*np.linspace(.1,1,n)**1.5*env(n,.01,.03); return y*1.2+.25*sweep(180,900,d,2)*np.linspace(0,1,n)*env(n,.01,.03)
def flash(d=.55):
    n=int(d*SR); b=sweep(130,38,d,.6)*decay(n,5); h=hp(noise(n),2500)*decay(n,9); return b*.9+h*.5
def thud(d=.32):
    n=int(d*SR); b=sweep(100,42,d,.5)*decay(n,7); c=lp(noise(n),500)*decay(n,30); return b*1.1+c*.9
def step(d=.14):
    n=int(d*SR); return sweep(75,45,d)*decay(n,9)*.9+lp(noise(n),300)*decay(n,35)*.5
def pop(d=.12):
    n=int(d*SR); return sweep(420,980,d,.6)*decay(n,9)*.9+hp(noise(n),3000)*decay(n,60)*.3
def zap(d=.14):
    n=int(d*SR); t=T(d); s=np.sign(np.sin(2*np.pi*(1500-3000*t)*t))*.35; return s*(0.6+.4*np.sin(2*np.pi*90*t))*decay(n,6)
def fizz(d=.5):
    n=int(d*SR); return lp(hp(noise(n),900),np.linspace(5000,600,n))*decay(n,4)*1.4
def chime(d=.9):
    out=np.zeros(int(d*SR)+int(.3*SR))
    for k,f in enumerate((784,988,1175,1568,1976)):
        n=int(.7*SR); t=np.arange(n)/SR; w=(np.sin(2*np.pi*f*t)+.3*np.sin(2*np.pi*2*f*t))*decay(n,5)*.3
        o=int(k*.06*SR); out[o:o+n]+=w
    return out
def swish(d=.2): return whoosh(d,6000)*.9
def crack(d=.18):
    n=int(d*SR); return hp(noise(n),1500)*decay(n,22)*1.6+sweep(240,70,d,.5)*decay(n,14)*1.0
def boing(d=.45):
    t=T(d); f=200+260*np.sin(np.pi*np.minimum(t/d*1.4,1))+30*np.sin(2*np.pi*14*t); return np.sin(2*np.pi*np.cumsum(f)/SR)*decay(len(t),4)*.7
def fall(): 
    b=boing(.4); th=thud(.4); out=np.zeros(int(.8*SR)); out[:len(b)]+=b*.7; o=int(.38*SR); out[o:o+len(th)]+=th*1.2; return out
def beat():
    a=thud(.22)*.9; b=thud(.2)*.6; out=np.zeros(int(.4*SR)); out[:len(a)]+=a*.8; o=int(.17*SR); out[o:o+len(b)]+=b*.8; return out
def buzz(d=.3):
    t=T(d); s=2*((t*150)%1)-1; return lp(s,1200)*decay(len(t),4)*.6
def glitch(d=.25):
    n=int(d*SR); x=noise(n)*np.sign(np.sin(2*np.pi*35*T(d))); x=np.round(x*4)/4; return x*decay(n,5)*.9
def air(d):
    n=int(d*SR); return lp(noise(n),np.full(n,600))*.012

G={'whoosh':whoosh,'zoom':zoom,'flash':flash,'thud':thud,'step':step,'pop':pop,'zap':zap,'fizz':fizz,'chime':chime,'swish':swish,'crack':crack,'boing':boing,'fall':fall,'beat':beat,'buzz':buzz,'glitch':glitch}
D=json.load(open('sfx.json')); total=D['total']; N=int((total+.5)*SR)
subprocess.run(['ffmpeg','-y','-loglevel','error','-i','narr.mp3','-ac','1','-ar',str(SR),'narr.wav'],check=True)
w=wave.open('narr.wav'); v=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(np.float64)/32768; w.close()
OFF=int(.5*SR); voice=np.zeros(N); voice[OFF:OFF+len(v)]=v[:N-OFF]
sfx=np.zeros(N); cache={}
for t,k,vol in D['sfx']:
    if k not in cache: cache[k]=G[k]()
    s=cache[k]*vol; i=int(max(0,t)*SR); e=min(N,i+len(s)); sfx[i:e]+=s[:e-i]
sfx=np.tanh(sfx*1.1)
# duck sfx under voice so narration stays clear
ve=np.abs(voice); k=int(.06*SR); ve=np.convolve(ve,np.ones(k)/k,mode='same'); duck=1-.45*np.clip(ve/.12,0,1)
mix=voice*1.0+sfx*.34*duck+air(N/SR)[:N]
mix=mix/max(1,np.max(np.abs(mix))/.97)
st=np.stack([mix,mix],1); out=(st*32767).astype(np.int16)
w=wave.open('mix.wav','wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(out.tobytes()); w.close()
print('ok',N/SR,'peak',np.max(np.abs(mix)))
