import numpy as np, wave
SR=44100; TOT=77.54; N=int((TOT+.5)*SR); BEAT=.6
rng=np.random.default_rng(11)
def hz(m): return 440*2**((m-69)/12)
def T(d): return np.arange(int(d*SR))/SR
def put(buf,t,sig,g=1.0):
    i=int(t*SR)
    if i>=len(buf) or i<0: return
    e=min(len(buf),i+len(sig)); buf[i:e]+=sig[:e-i]*g
def tone(m,d,harm=((1,1),(2,.35),(3,.12)),a=.004,dec=4,rel=.04):
    t=T(d); f=hz(m); s=sum(h_*np.sin(2*np.pi*f*k*t) for k,h_ in harm)
    e=np.minimum(1,t/a)*np.exp(-dec*t)*np.minimum(1,(d-t)/rel); return s*e
def pluck(m,d=.4): return tone(m,d,((1,1),(2,.5),(3,.25),(4,.1)),.003,9,.03)
def bell(m,d=1.2): return tone(m,d,((1,1),(2.76,.3),(5.4,.12)),.002,3.2,.1)
def bass(m,d=.5): return tone(m,d,((1,1),(2,.5),(3,.2)),.006,3.5,.05)
def pad(ms,d):
    out=np.zeros(int(d*SR)); t=T(d)
    for m in ms:
        for dt in (.997,1.003):
            f=hz(m)*dt; out+=(np.sin(2*np.pi*f*t)+.4*np.sin(2*np.pi*2*f*t)+.15*np.sin(2*np.pi*3*f*t))*.25
    e=np.minimum(1,t/(.7))*np.minimum(1,(d-t)/.5); return out*e
def kick(vol=1):
    d=.28; t=T(d); f=50+110*np.exp(-t*28); ph=2*np.pi*np.cumsum(f)/SR; return np.sin(ph)*np.exp(-t*11)*vol+ (rng.standard_normal(len(t))*np.exp(-t*90))*.12*vol
def clap(vol=1):
    d=.18; n=int(d*SR); x=np.diff(rng.standard_normal(n+1)); t=T(d); return x*np.exp(-t*24)*.5*vol
def shaker(vol=1):
    d=.07; n=int(d*SR); x=np.diff(rng.standard_normal(n+1)); t=T(d); return x*np.exp(-t*55)*.3*vol
def riser(d):
    n=int(d*SR); t=T(d); x=np.diff(rng.standard_normal(n+1)); return x*(t/d)**2*.5+np.sin(2*np.pi*np.cumsum(200+1400*(t/d)**2)/SR)*(t/d)**2*.25

mus=np.zeros(N)
bar=BEAT*4
def chords(t0,t1,prog,fn):
    t=t0;k=0
    while t<t1-1e-6:
        fn(t,prog[k%len(prog)],min(bar,t1-t));t+=bar;k+=1
# progressions: (root midi, third, fifth)
Am=(45,48,52);F=(41,45,48);C=(48,52,55);G=(43,47,50);E=(40,44,47);Am2=Am;Dm=(38,41,45)
def tri(root,third,fifth,o=12): return [root+o,third+o,fifth+o]

# S0: suave, caixa de musica
put(mus,0,pad([57,60,64],5.9),.5)
mel=[76,81,84,83,81,79,76,74]
for i,m in enumerate(mel): put(mus,.3+i*.6,bell(m),.45)
# S1: groove divertido 5.7-35
def groove(t,ch,L):
    r,th,fi=ch
    for b in range(4):
        tb=t+b*BEAT
        if tb>=t+L: break
        put(mus,tb,bass(r+12,.45),.9 if b%2==0 else .6)
        put(mus,tb+BEAT/2,pluck(r+12+(7 if b%2 else 0),.2),.35)
        for m in tri(r,th,fi,24):put(mus,tb+BEAT/2,pluck(m,.25),.22)
        if b%2==0: put(mus,tb,kick(.8),.5)
        put(mus,tb,shaker(),.5);put(mus,tb+BEAT/2,shaker(),.35)
    put(mus,t,pad([r+12,th+12,fi+12],L),.18)
chords(5.7,35,[Am,F,C,G],groove)
# S2: tensao 35-48
def tense(t,ch,L):
    r,th,fi=ch
    for b in range(8):
        tb=t+b*BEAT/2
        if tb>=t+L: break
        put(mus,tb,bass(r,.28),.8)
    for b in range(4):
        tb=t+b*BEAT
        if tb<t+L: put(mus,tb,kick(.9),.55)
    put(mus,t,pad([r+12,th+12,fi+12],L),.22)
chords(35,48,[Am,Am,F,E],tense)
put(mus,43,riser(5.0),.25)
# S3: ataque dos soldados 48-57
def attack(t,ch,L):
    r,th,fi=ch
    for b in range(16):
        tb=t+b*BEAT/4
        if tb>=t+L: break
        m=[r+24,th+24,fi+24,th+24][b%4]
        put(mus,tb,pluck(m,.12),.3)
    for b in range(8):
        tb=t+b*BEAT/2
        if tb<t+L: put(mus,tb,bass(r,.25),.8)
    for b in range(4):
        tb=t+b*BEAT
        if tb<t+L: put(mus,tb,kick(1),.6)
        if b%2==1 and tb<t+L: put(mus,tb,clap(),.5)
chords(48,57,[Am,E,F,E],attack)
# S4: esquisito (Tita anormal) 57-66.6
q=[69,70,69,68,69,72,70,69]
t=57;k=0
while t<66.6:
    for j in range(8):
        tb=t+j*BEAT/2
        if tb>=66.6: break
        put(mus,tb,pluck(q[(j+k)%8]+(12 if j%3==0 else 0),.14),.4)
        if j%2==0: put(mus,tb,bass([45,46,45,43][j//2%4],.2),.8)
    put(mus,t,kick(.8),.5);put(mus,t+BEAT*2,kick(.8),.5);put(mus,t+BEAT,clap(),.45);put(mus,t+BEAT*3,clap(),.45)
    t+=bar;k+=3
# S5: caloroso (por do sol) 66.6-71
put(mus,66.6,pad([60,64,67,72],2.4),.5);put(mus,69.0,pad([57,60,65,69],2.2),.5)
for i,m in enumerate([72,76,79,84,79,76,81,84]): put(mus,66.7+i*.5,bell(m,1.0),.4)
# S6: final agitado 71-77.5
def finale(t,ch,L):
    r,th,fi=ch
    for b in range(16):
        tb=t+b*BEAT/4
        if tb>=t+L: break
        put(mus,tb,pluck([r+24,th+24,fi+24,th+36][b%4],.1),.3)
    for b in range(4):
        tb=t+b*BEAT
        if tb<t+L: put(mus,tb,kick(1),.65);put(mus,tb+BEAT/2,shaker(),.5);put(mus,tb,bass(r+12,.4),.8)
chords(71,TOT,[Am,F,C,G],finale)
put(mus,71.0,riser(1.2),.0)
put(mus,76.6,kick(1.2),.8);put(mus,76.6,pad([57,60,64,69],1.2),.4)
# fade-out
fo=int(1.0*SR); mus[int((TOT-1.0)*SR):int((TOT-1.0)*SR)+fo]*=np.linspace(1,0,fo)
mus[int(TOT*SR):]=0
mus/=max(1e-9,np.max(np.abs(mus)))
# haas stereo
d=int(.012*SR); L=mus.copy(); R=np.concatenate([np.zeros(d),mus[:-d]])
# voz (envelope) para ducking
w=wave.open('narr.wav'); v=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(np.float64)/32768; w.close()
voice=np.zeros(N); o=int(.5*SR); voice[o:o+len(v)]=v[:N-o]
ve=np.convolve(np.abs(voice),np.ones(int(.08*SR))/int(.08*SR),mode='same'); duck=1-.62*np.clip(ve/.08,0,1)
w=wave.open('mix.wav'); base=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(np.float64).reshape(-1,2)/32768; w.close()
M=min(N,len(base)); gain=.30
out=base[:M].copy(); out[:,0]+=L[:M]*duck[:M]*gain; out[:,1]+=R[:M]*duck[:M]*gain
out/=max(1,np.max(np.abs(out))/.97)
w=wave.open('mix_music.wav','wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((out*32767).astype(np.int16).tobytes()); w.close()
print('ok',M/SR)
