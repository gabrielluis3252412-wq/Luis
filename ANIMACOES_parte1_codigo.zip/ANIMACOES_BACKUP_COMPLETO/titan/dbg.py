import os,sys
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':1080,'height':1920})
    pg.on('pageerror',lambda e:print('ERR',e))
    pg.goto('file:///home/claude/titan/story.html')
    for i,u in [(1,.7),(1,.8)]:
        sh=pg.evaluate('SH.map(s=>[s.t0,s.t1])')[i];t=sh[0]+(sh[1]-sh[0])*u
        pg.evaluate(f"F({t})")
        print(i,u,pg.evaluate("[CHS.CIB.sp,HEAD(-78),UW(1,'enorme',.6),UW(1,'desajeitados',.3),UW(1,'tropeçando',.25),UW(1,'andando',.15)]"))
    b.close()
