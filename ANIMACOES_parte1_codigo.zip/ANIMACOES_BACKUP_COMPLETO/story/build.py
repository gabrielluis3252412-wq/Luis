# Remonta story.html (animação) e plates.html (cenários 3D) depois de editar lib.js / sets.js / main.js / plates_main.js
# Uso:  cd /home/claude/titan && python3 build.py   (ou dentro de story/)
import os
S='const INK="#1b1024",S=`stroke="${INK}" stroke-width="7" stroke-linejoin="round" stroke-linecap="round"`;\n'
r=lambda f:open(f,encoding='utf-8').read()
h=r('story.html');head=h[:h.index('<script>')+8]
open('story.html','w',encoding='utf-8').write(head+S+r('lib.js')+'\n'+r('sets.js')+'\n'+r('main.js')+'\n</script></body></html>')
p='<!DOCTYPE html><html><head><meta charset="utf-8"><style>body{margin:0;background:#000}canvas{width:300px}</style></head><body><canvas id="A"></canvas><canvas id="B"></canvas><script>'
open('plates.html','w',encoding='utf-8').write(p+S+r('lib.js')+'\n'+r('sets.js')+'\n'+r('plates_main.js')+'\n</script></body></html>')
print('story.html e plates.html remontados')
