import os,sys,base64,time
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
keys=sys.argv[1:]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    pg=b.new_page(viewport={'width':800,'height':800})
    pg.on('pageerror',lambda e:print('ERR',e));pg.on('console',lambda m:print('LOG',m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/story/plates.html')
    keys=keys or pg.evaluate("Object.keys(PLATES)")
    for k in keys:
        t=time.time();A,B=pg.evaluate(f"plate('{k}')")
        for n,d in (('A',A),('B',B)): open(f'/home/claude/story/plates/{k}_{n}.png','wb').write(base64.b64decode(d.split(',')[1]))
        print(k,round(time.time()-t,1),flush=True)
    b.close()
