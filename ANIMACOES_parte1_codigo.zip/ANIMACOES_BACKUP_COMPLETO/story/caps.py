import json,re,os
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page();pg.goto('file:///home/claude/story/story.html');segs=pg.evaluate('SEGT');tot=pg.evaluate('TOTAL');b.close()
COL=['3FD2FF','8F5DFF','FFD94C','6BFF7D']
def toks(t):
    out=[];hl=False;gid=-1
    for part in re.split(r'(\*)',t):
        if part=='*':hl=not hl;gid+=1 if hl else 0;continue
        for w in part.split():out.append((w,hl,gid))
    return out
def ts(x):
    h=int(x//3600);m=int(x%3600//60);s=x%60;return f"{h}:{m:02d}:{s:05.2f}"
ev=[];ci=0
for text,a,bb in segs:
    w=toks(text);ch=[];cur=[]
    for k,(x,h,g) in enumerate(w):
        cur.append((x,h,g))
        if (len(cur)>=6) or (len(cur)>=3 and re.search(r'[.,!?:]$',x)):ch.append(cur);cur=[]
    if cur:
        if ch and len(cur)<2:ch[-1]+=cur
        else:ch.append(cur)
    L=[sum(len(x)+1 for x,_,_ in c) for c in ch];tot_l=sum(L);dur=(bb-a)-.25;t=a
    for c,l in zip(ch,L):
        d=dur*l/tot_l;s=''
        for x,h,g in c:
            if h:s+='{\\c&H%s&}%s{\\c&HFFFFFF&} '%(COL[(g+ci)%4],x)
            else:s+=x+' '
        ev.append((t,t+d-.02,s.strip()));t+=d
    ci+=1
hdr='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 0

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Cap,Poppins,82,&H00FFFFFF,&H00FFFFFF,&H00241018,&H00000000,1,0,0,0,100,100,0,0,1,9,2,2,70,70,330,1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
'''
open('/mnt/user-data/outputs/jorisvaldo-sexta13.ass','w',encoding='utf-8').write(hdr+''.join(f"Dialogue: 0,{ts(a)},{ts(b)},Cap,,0,0,0,,{t}\n" for a,b,t in ev))
print(len(ev),'legendas; total',round(tot,1))
