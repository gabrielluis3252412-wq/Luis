import os,math
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
from playwright.sync_api import sync_playwright
FPS=24
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':1080,'height':1920})
    pg.on('pageerror',lambda e:print('ERR',e));pg.goto('file:///home/claude/story/story.html')
    sh=pg.evaluate('SH.map(s=>[s.t0,s.t1])');n=0
    for idx in (4,16):
        t0,t1=sh[idx]
        for i in range(int(t0*FPS)-1,int(math.ceil(t1*FPS))+1):
            if i<0 or i>=3713:continue
            pg.evaluate(f"F({i/FPS})");pg.screenshot(path=f'frames5/{i:05d}.jpg',type='jpeg',quality=92);n+=1
    b.close();print('refeitos',n)
